/**
 * Hadith Fetcher Admin Scripts
 */
(function($) {
    'use strict';
    
    // Debug initialization
    console.log('Hadith Fetcher admin.js initialized - Version: ' + (typeof hadithFetcherAdmin !== 'undefined' ? 'Loaded' : 'Not Loaded'));
    
    // Check if admin object is available
    if (typeof hadithFetcherAdmin === 'undefined') {
        console.error('hadithFetcherAdmin object is not defined - this indicates the script was not properly localized');
    } else {
        console.log('hadithFetcherAdmin settings loaded:', hadithFetcherAdmin);
    }
    
    // Helper functions for bulk import - moved inside initialization to maintain proper scope
    function showStatus(type, message) {
        const $status = $('#fetch-status');
        $status.removeClass('success error loading').addClass(type);
        $status.html(message);
        $status.show();
    }
    
    function showBulkStatus(type, message) {
        const $status = $('#bulk-status');
        $status.removeClass('success error loading').addClass(type);
        $status.html(message);
        $status.show();
    }
    
    function updateProgress(percent) {
        $('.progress-fill').css('width', percent + '%');
        $('.progress-text').text(percent + '%');
    }
    
    function appendToLog(message) {
        const timestamp = new Date().toLocaleTimeString();
        $('#bulk-log').append('[' + timestamp + '] ' + message + '<br>');
        $('#bulk-log').scrollTop($('#bulk-log')[0].scrollHeight);
    }
    
    function formatText(text) {
        if (!text) return '';
        
        // Remove unwanted slashes
        text = text.replace(/\//g, '');
        
        // Fix line breaks after periods
        text = text.replace(/\.\s+/g, '. ');
        
        // Remove excess whitespace
        text = text.replace(/\s+/g, ' ');
        
        // Trim whitespace
        return text.trim();
    }
    
    // Helper function for translation strings
    function __(text) {
        return text; // Simple implementation - in a real plugin, this would use WordPress translation functions
    }
    
    // Helper function to get collection name
    function getCollectionName(collectionSlug) {
        const collections = {
            'bukhari': 'Sahih al-Bukhari',
            'muslim': 'Sahih Muslim',
            'abudawud': 'Sunan Abu Dawud',
            'tirmidhi': 'Jami` at-Tirmidhi',
            'nasai': 'Sunan an-Nasa\'i',
            'ibnmajah': 'Sunan Ibn Majah',
            'malik': 'Muwatta Malik'
        };
        
        return collections[collectionSlug] || collectionSlug;
    }
    
    // Make showHadithPreview global so it can be accessed by inline scripts
    window.showHadithPreview = function(hadithData) {
        console.log('Showing hadith preview:', hadithData);
        
        // Get preview element
        const $preview = $('#hadith-preview');
        
        // Create preview HTML
        let html = '';
        
        // Add Arabic text if available
        if (hadithData.arabic_text) {
            html += '<div class="hadith-preview-arabic">';
            html += '<h3>' + __('Arabic Text') + '</h3>';
            html += '<div class="arabic-text">' + hadithData.arabic_text + '</div>';
            html += '</div>';
        }
        
        // Add English translation if available
        if (hadithData.english_default) {
            html += '<div class="hadith-preview-english">';
            html += '<h3>' + __('English Translation') + '</h3>';
            html += '<div class="english-text">' + formatText(hadithData.english_default) + '</div>';
            html += '</div>';
        }
        
        // Add Urdu translation if available
        if (hadithData.urdu_default) {
            html += '<div class="hadith-preview-urdu">';
            html += '<h3>' + __('Urdu Translation') + '</h3>';
            html += '<div class="urdu-text">' + hadithData.urdu_default + '</div>';
            html += '</div>';
        } else {
            console.log('No Urdu translation available for this hadith');
        }
        
        // Add Bengali translation if available
        if (hadithData.bengali_default) {
            html += '<div class="hadith-preview-bengali">';
            html += '<h3>' + __('Bengali Translation') + '</h3>';
            html += '<div class="bengali-text">' + hadithData.bengali_default + '</div>';
            html += '</div>';
        } else {
            console.log('No Bengali translation available for this hadith');
        }
        
        // Add metadata
        html += '<div class="hadith-preview-meta">';
        html += '<h3>' + __('Metadata') + '</h3>';
        html += '<ul>';
        
        // Add collection and book
        html += '<li><strong>' + __('Collection') + ':</strong> ' + getCollectionName(hadithData.collection) + '</li>';
        
        // Ensure book number is always displayed
        const bookNumber = hadithData.book_number || book || 'Not specified';
        html += '<li><strong>' + __('Book Number') + ':</strong> ' + bookNumber + '</li>';
        
        // Add hadith number
        if (hadithData.hadith_number) {
            html += '<li><strong>' + __('Hadith Number') + ':</strong> ' + hadithData.hadith_number + '</li>';
        }
        
        // Add book name
        if (hadithData.book_name) {
            html += '<li><strong>' + __('Book Name') + ':</strong> ' + hadithData.book_name + '</li>';
        }
        
        // Add chapter name
        if (hadithData.chapter_name) {
            html += '<li><strong>' + __('Chapter') + ':</strong> ' + hadithData.chapter_name + '</li>';
        }
        
        // Add volume
        if (hadithData.volume) {
            html += '<li><strong>' + __('Volume') + ':</strong> ' + hadithData.volume + '</li>';
        }
        
        // Add page
        if (hadithData.page) {
            html += '<li><strong>' + __('Page') + ':</strong> ' + hadithData.page + '</li>';
        }
        
        // Add authenticity grade
        if (hadithData.authenticity) {
            html += '<li><strong>' + __('Authenticity') + ':</strong> ' + hadithData.authenticity + '</li>';
        }
        
        // Add narrators
        if (hadithData.narrators && hadithData.narrators.length > 0) {
            html += '<li><strong>' + __('Narrators') + ':</strong> ' + hadithData.narrators.join(', ') + '</li>';
        }
        
        // Add additional info - Improved formatting for better readability
        if (hadithData.additional_info) {
            html += '<li><strong>' + __('Additional References') + ':</strong><br>';
            // Split by newline and create a nicely formatted list
            const infoLines = hadithData.additional_info.split('\n').filter(line => line.trim() !== '');
            if (infoLines.length > 0) {
                html += '<ul class="additional-references">';
                infoLines.forEach(line => {
                    if (line.trim() !== '') {
                        html += '<li>' + line + '</li>';
                    }
                });
                html += '</ul>';
            } else {
                html += hadithData.additional_info;
            }
            html += '</li>';
        }
        
        html += '</ul>';
        html += '</div>';
        
        // Taxonomies information
        html += '<div class="hadith-preview-taxonomies">';
        html += '<h3>Taxonomies</h3>';
        html += '<ul>';
        
        // Books taxonomy with hierarchy
        html += '<li><strong>Books:</strong> ';
        
        if (hadithData.chapter_name && hadithData.book_name) {
            // Full path: Collection > Book > Chapter
            html += 'Will be categorized in hierarchy: ' + 
                   '<span class="taxonomy-path">' + 
                   getCollectionName(hadithData.collection) + 
                   ' &raquo; ' + hadithData.book_name + 
                   ' &raquo; ' + hadithData.chapter_name + 
                   '</span>';
        } else if (hadithData.book_name) {
            // Just Collection > Book
            html += 'Will be categorized in hierarchy: ' + 
                   '<span class="taxonomy-path">' + 
                   getCollectionName(hadithData.collection) + 
                   ' &raquo; ' + hadithData.book_name + 
                   '</span>';
        } else {
            // Just Collection
            html += 'Will be categorized under: ' + 
                   '<span class="taxonomy-path">' + 
                   getCollectionName(hadithData.collection) + 
                   '</span>';
        }
        
        html += '</li>';
        
        // Other taxonomies
        if (hadithData.authenticity) {
            html += '<li><strong>Authenticity:</strong> Will add "' + hadithData.authenticity + '"</li>';
        }
        if (hadithData.narrators && hadithData.narrators.length > 0) {
            html += '<li><strong>Narrators:</strong> Will add ' + hadithData.narrators.length + ' narrator(s)</li>';
        }
        html += '</ul>';
        html += '</div>';
        
        // Add JSON data structure preview
        html += '<div class="hadith-preview-json">';
        html += '<h3>JSON Data Structure</h3>';
        html += '<p>This is the JSON structure that will be used to save the hadith:</p>';
        html += '<pre class="json-preview">';
        
        try {
            // Use the formatted JSON from the server if available
            if (hadithData.formatted_json) {
                html += hadithData.formatted_json;
            } else {
                // Create the formatted JSON structure (fallback)
                const jsonData = {
                    post: {
                        post_title: 'Hadith ' + hadithData.hadith_number + ' - ' + hadithData.book_name,
                        post_status: 'publish',
                        post_type: 'hadith'
                    },
                    meta: {
                        hadith_arabic_text: hadithData.arabic_text || '',
                        hadith_collection: hadithData.collection || '',
                        hadith_book: hadithData.book_number || '',
                        hadith_number: hadithData.hadith_number || ''
                    },
                    reference: {
                        book_name: hadithData.book_name || '',
                        volume_number: hadithData.volume || '',
                        page_number: hadithData.page || '',
                        hadith_number: hadithData.hadith_number || '',
                        authenticity_grade: hadithData.authenticity || '',
                        additional_reference: hadithData.additional_info || ''
                    },
                    narrators: [],
                    translations: []
                };
                
                // Add narrators
                if (hadithData.narrators && hadithData.narrators.length > 0) {
                    hadithData.narrators.forEach(function(narrator, index) {
                        jsonData.narrators.push({
                            narrator_name: narrator,
                            narrator_info: '',
                            position: index + 1
                        });
                    });
                }
                
                // Add translations
                const translations = {
                    en: formatText(hadithData.english_default),
                    ur: hadithData.urdu_default,
                    bn: hadithData.bengali_default,
                    fr: hadithData.french_default || '',
                    es: hadithData.spanish_default || '',
                    tr: hadithData.turkish_default || '',
                    id: hadithData.indonesian_default || ''
                };
                
                for (const lang in translations) {
                    if (translations[lang]) {
                        jsonData.translations.push({
                            language_code: lang,
                            scholar_id: 1,
                            translation_text: translations[lang]
                        });
                    }
                }
                
                html += JSON.stringify(jsonData, null, 2);
            }
        } catch (error) {
            console.error('Error generating JSON preview:', error);
            html += 'Error generating JSON preview: ' + error.message;
        }
        
        html += '</pre>';
        html += '</div>';
        
        // Add save button
        html += '<div class="hadith-preview-actions">';
        html += '<button id="save-hadith" class="button button-primary">' + hadithFetcherAdmin.save_text + '</button>';
        html += '</div>';
        
        // Update preview
        $preview.html(html).show();
        
        // Scroll to preview
        $('html, body').animate({
            scrollTop: $preview.offset().top - 100
        }, 500);
    }
    
    function processNextHadith(collection, book, current, end, importedCount, failedCount, totalHadiths, overwrite) {
        if (current > end) {
            // All done
            showBulkStatus('success', 'Bulk import completed. ' + importedCount + ' hadiths imported, ' + failedCount + ' failed.');
            appendToLog('Bulk import completed. ' + importedCount + ' hadiths imported, ' + failedCount + ' failed.');
            return;
        }
        
        // Update status
        showBulkStatus('loading', 'Importing hadith ' + current + ' of ' + end + '...');
        appendToLog('Importing hadith ' + current + '...');
        
        // Send AJAX request
        $.ajax({
            url: hadithFetcherAdmin.ajax_url,
            type: 'POST',
            data: {
                action: 'fetch_hadith',
                nonce: hadithFetcherAdmin.nonce,
                collection: collection,
                book: book,
                hadith: current,
                overwrite: overwrite ? 1 : 0
            },
            success: function(response) {
                try {
                    if (response.success) {
                        importedCount++;
                        appendToLog('Success: Hadith ' + current + ' imported. ID: ' + response.data.post_id);
                    } else {
                        failedCount++;
                        appendToLog('Error: Failed to import hadith ' + current + '. ' + response.data.message);
                    }
                    
                    // Update progress
                    const progress = Math.round(((current - (end - totalHadiths + 1) + 1) / totalHadiths) * 100);
                    updateProgress(progress);
                    
                    // Process next hadith
                    setTimeout(function() {
                        processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite);
                    }, hadithFetcherAdmin.fetch_delay);
                } catch (err) {
                    console.error('Error processing hadith response:', err);
                    failedCount++;
                    appendToLog('Error: Failed to process hadith ' + current + ' response. See console for details.');
                    
                    // Continue with next hadith
                    setTimeout(function() {
                        processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite);
                    }, hadithFetcherAdmin.fetch_delay);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error for hadith ' + current + ':', status, error);
                failedCount++;
                appendToLog('Error: Failed to import hadith ' + current + '. Network error: ' + status);
                
                // Update progress
                const progress = Math.round(((current - (end - totalHadiths + 1) + 1) / totalHadiths) * 100);
                updateProgress(progress);
                
                // Process next hadith
                setTimeout(function() {
                    processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite);
                }, hadithFetcherAdmin.fetch_delay);
            }
        });
    }
    
    // Wait for DOM to be ready
    $(document).ready(function() {
        console.log('DOM ready');
        
        // Check if we have the admin settings object
        if (typeof hadithFetcherAdmin === 'undefined') {
            console.error('hadithFetcherAdmin object is not defined');
            return;
        }
        
        console.log('Admin settings:', hadithFetcherAdmin);
        
        // Initialize bulk import functionality - this should work on any page with the button
        if ($('#bulk-fetch').length) {
            console.log('Found bulk-fetch button, initializing bulk import functionality...');
            
            // Bulk import
            $('#bulk-fetch').on('click', function() {
                console.log('Bulk import button clicked');
                
                const collection = $('#bulk-collection').val();
                const book = $('#bulk-book').val();
                const startHadith = parseInt($('#bulk-start').val());
                const endHadith = parseInt($('#bulk-end').val());
                const overwrite = $('#bulk-overwrite').is(':checked');
                
                console.log('Import parameters:', {
                    collection,
                    book,
                    startHadith,
                    endHadith,
                    overwrite,
                    fetch_delay: hadithFetcherAdmin.fetch_delay
                });
                
                // Validate inputs
                if (!collection || !book || isNaN(startHadith) || isNaN(endHadith)) {
                    showBulkStatus('error', 'Please fill in all fields');
                    return;
                }
                
                if (startHadith > endHadith) {
                    showBulkStatus('error', 'Start hadith number must be less than or equal to end hadith number');
                    return;
                }
                
                // Show progress bar
                $('.progress-container').show();
                updateProgress(0);
                
                // Show loading status
                showBulkStatus('loading', 'Starting bulk import...');
                
                // Show bulk log
                $('#bulk-log').empty().show();
                appendToLog('Starting bulk import of hadiths ' + startHadith + ' to ' + endHadith + ' from collection: ' + collection);
                
                // Start bulk import
                const totalHadiths = endHadith - startHadith + 1;
                let importedCount = 0;
                let failedCount = 0;
                
                // Process hadiths one by one
                processNextHadith(collection, book, startHadith, endHadith, importedCount, failedCount, totalHadiths, overwrite);
            });
        }
        
        // Only initialize remaining functionality if we're on the hadith fetcher admin page
        if ($('#hadith-fetcher-admin').length) {
            console.log('Found hadith-fetcher-admin element, initializing...');
            
            // Initialize custom field inputs
            $('.custom-field-input').hide();
            
            // Field mapping
            $('.field-mapping-select').each(function() {
                const $select = $(this);
                const fieldKey = $select.data('field');
                
                // Show/hide custom field input based on selected value
                $select.on('change', function() {
                    const selectedValue = $(this).val();
                    const $customInput = $('input.custom-field-input[data-field="' + fieldKey + '"]');
                    
                    if (selectedValue === 'custom') {
                        $customInput.show();
                    } else {
                        $customInput.hide();
                    }
                }).trigger('change');
            });
            
            // Handle form submission for custom fields
            $('form').on('submit', function() {
                $('.field-mapping-select').each(function() {
                    const fieldKey = $(this).data('field');
                    const selectedValue = $(this).val();
                    
                    if (selectedValue === 'custom') {
                        // Get custom field input value
                        const customValue = $('input.custom-field-input[data-field="' + fieldKey + '"]').val();
                        
                        if (customValue.trim() !== '') {
                            // Set the select value to the custom value
                            $(this).val(customValue);
                        }
                    }
                });
            });
            
            // Single hadith fetch - use direct jQuery event binding without off().on() 
            $('#fetch-hadith').on('click', function(e) {
                // Prevent default action to avoid any form submission
                e.preventDefault();
                
                // Log the click event to confirm it's being triggered
                console.log('Fetch hadith button clicked');
                
                const collection = $('#hadith-collection').val();
                const book = $('#hadith-book').val();
                const hadithNumber = $('#hadith-number').val();
                
                console.log('Fetching hadith:', collection, book, hadithNumber);
                
                // Validate inputs
                if (!collection || !book || !hadithNumber) {
                    showStatus('error', 'Please fill in all fields');
                    return;
                }
                
                // Show loading status
                showStatus('loading', hadithFetcherAdmin.fetching_text);
                
                // First fetch the hadith for preview
                $.ajax({
                    url: hadithFetcherAdmin.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'fetch_hadith',
                        nonce: hadithFetcherAdmin.nonce,
                        collection: collection,
                        book: book,
                        hadith: hadithNumber,
                        preview_only: true
                    },
                    success: function(response) {
                        try {
                            console.log('AJAX response:', response);
                            
                            if (response.success) {
                                // Display success message
                                showStatus('success', response.data.message);
                                
                                // Show hadith preview
                                showHadithPreview(response.data.data);
                                
                                // Handle save button click - use event delegation for reliability
                                $(document).off('click', '#save-hadith').on('click', '#save-hadith', function() {
                                    console.log('Save hadith button clicked');
                                    
                                    // Show saving message
                                    showStatus('loading', hadithFetcherAdmin.saving_text);
                                    
                                    // Send AJAX request to save hadith
                                    $.ajax({
                                        url: hadithFetcherAdmin.ajax_url,
                                        type: 'POST',
                                        data: {
                                            action: 'fetch_hadith',
                                            nonce: hadithFetcherAdmin.nonce,
                                            collection: collection,
                                            book: book,
                                            hadith: hadithNumber,
                                            preview_only: false
                                        },
                                        success: function(saveResponse) {
                                            try {
                                                console.log('Save response:', saveResponse);
                                                
                                                if (saveResponse.success) {
                                                    // Display success message with link to edit hadith
                                                    showStatus('success', saveResponse.data.message + ' <a href="' + saveResponse.data.edit_url + '" target="_blank">Edit hadith</a>');
                                                } else {
                                                    // Display error message
                                                    showStatus('error', saveResponse.data.message || 'Unknown error occurred');
                                                }
                                            } catch (err) {
                                                console.error('Error processing save response:', err);
                                                showStatus('error', 'Error processing response: ' + err.message);
                                            }
                                        },
                                        error: function(xhr, status, error) {
                                            // Display error message
                                            console.error('Save AJAX error:', status, error);
                                            showStatus('error', 'Error saving hadith: ' + status + ' - ' + error);
                                        }
                                    });
                                });
                            } else {
                                // Display error message
                                showStatus('error', response.data.message || 'Unknown error occurred');
                            }
                        } catch (err) {
                            console.error('Error processing fetch response:', err);
                            showStatus('error', 'Error processing response: ' + err.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        // Display error message
                        console.error('Fetch AJAX error:', status, error);
                        showStatus('error', hadithFetcherAdmin.error_text + ': ' + status + ' - ' + error);
                    }
                });
            });
            
            // Cancel button - use event delegation for dynamically created elements
            $(document).on('click', '#cancel-save', function() {
                $('#hadith-preview').hide();
            });
        }
    });
})(jQuery);