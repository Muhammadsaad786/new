/**
 * Hadith Fetcher logs admin JavaScript
 */
(function($) {
    'use strict';
    
    $(document).ready(function() {
        const modal = $('#log-details-modal');
        const modalContent = modal.find('.log-context code');
        const closeBtn = modal.find('.close');
        
        // Open modal when clicking "View" button
        $('.view-context').on('click', function() {
            let context = $(this).data('context');
            
            // Format context as pretty JSON
            let formattedContext;
            try {
                if (typeof context !== 'object') {
                    context = JSON.parse(context);
                }
                formattedContext = JSON.stringify(context, null, 2);
            } catch (e) {
                formattedContext = context;
            }
            
            // Set modal content
            modalContent.text(formattedContext);
            
            // Show modal
            modal.css('display', 'block');
        });
        
        // Close modal when clicking close button or outside the modal
        closeBtn.on('click', function() {
            modal.css('display', 'none');
        });
        
        $(window).on('click', function(e) {
            if (e.target === modal[0]) {
                modal.css('display', 'none');
            }
        });
        
        // Handle "Clear All Logs" button
        $('#clear-logs').on('click', function() {
            if (confirm(hadithFetcherLogs.confirmClear)) {
                $.ajax({
                    url: hadithFetcherLogs.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'hadith_fetcher_clear_logs',
                        nonce: hadithFetcherLogs.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            alert(hadithFetcherLogs.clearSuccess);
                            location.reload();
                        } else {
                            alert(response.data);
                        }
                    },
                    error: function() {
                        alert(hadithFetcherLogs.clearError);
                    }
                });
            }
        });
        
        // Handle "Export CSV" button
        $('#export-logs').on('click', function() {
            // Get current filter values
            const level = $('#level').val();
            const component = $('#component').val();
            const search = $('#search').val();
            const dateFrom = $('#date_from').val();
            const dateTo = $('#date_to').val();
            
            // Create a form to submit the export request
            const form = $('<form>', {
                'method': 'post',
                'action': hadithFetcherLogs.ajaxurl,
                'target': '_blank'
            });
            
            // Add form fields
            $('<input>').attr({
                type: 'hidden',
                name: 'action',
                value: 'hadith_fetcher_export_logs'
            }).appendTo(form);
            
            $('<input>').attr({
                type: 'hidden',
                name: 'nonce',
                value: hadithFetcherLogs.nonce
            }).appendTo(form);
            
            $('<input>').attr({
                type: 'hidden',
                name: 'level',
                value: level
            }).appendTo(form);
            
            $('<input>').attr({
                type: 'hidden',
                name: 'component',
                value: component
            }).appendTo(form);
            
            $('<input>').attr({
                type: 'hidden',
                name: 'search',
                value: search
            }).appendTo(form);
            
            $('<input>').attr({
                type: 'hidden',
                name: 'date_from',
                value: dateFrom
            }).appendTo(form);
            
            $('<input>').attr({
                type: 'hidden',
                name: 'date_to',
                value: dateTo
            }).appendTo(form);
            
            // Append form to the body and submit it
            form.appendTo('body').submit().remove();
        });
        
        // Initialize date inputs if empty
        if ($('#date_from').val() === '') {
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
            const formattedDate = thirtyDaysAgo.toISOString().split('T')[0];
            $('#date_from').val(formattedDate);
        }
        
        if ($('#date_to').val() === '') {
            const today = new Date();
            const formattedDate = today.toISOString().split('T')[0];
            $('#date_to').val(formattedDate);
        }
    });
})(jQuery)