<?php
/**
 * Admin functionality for the Hadith Fetcher plugin
 */
class Hadith_Fetcher_Admin {
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Add top-level menu
        add_menu_page(
            __('Hadith Fetcher', 'hadith-fetcher'),
            __('Hadith Fetcher', 'hadith-fetcher'),
            'manage_options',
            'hadith-fetcher',
            array($this, 'render_main_page'),
            'dashicons-download',
            30
        );
        
        // Add submenu pages
        add_submenu_page(
            'hadith-fetcher',
            __('Fetch Hadiths', 'hadith-fetcher'),
            __('Fetch Hadiths', 'hadith-fetcher'),
            'manage_options',
            'hadith-fetcher',
            array($this, 'render_main_page')
        );
        
        add_submenu_page(
            'hadith-fetcher',
            __('Bulk Import', 'hadith-fetcher'),
            __('Bulk Import', 'hadith-fetcher'),
            'manage_options',
            'hadith-fetcher-bulk',
            array($this, 'render_bulk_page')
        );
        
        add_submenu_page(
            'hadith-fetcher',
            __('Custom Fields', 'hadith-fetcher'),
            __('Custom Fields', 'hadith-fetcher'),
            'manage_options',
            'hadith-fetcher-fields',
            array($this, 'render_fields_page')
        );
        
        add_submenu_page(
            'hadith-fetcher',
            __('Settings', 'hadith-fetcher'),
            __('Settings', 'hadith-fetcher'),
            'manage_options',
            'hadith-fetcher-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        // Register setting group with sanitize callback
        register_setting(
            'hadith_fetcher_settings', 
            'hadith_fetcher_options',
            array($this, 'sanitize_settings')
        );
        
        // Add settings section
        add_settings_section(
            'hadith_fetcher_main_section',
            __('Main Settings', 'hadith-fetcher'),
            array($this, 'render_settings_section'),
            'hadith-fetcher-settings'
        );
        
        // Add settings fields
        add_settings_field(
            'default_collection',
            __('Default Collection', 'hadith-fetcher'),
            array($this, 'render_default_collection_field'),
            'hadith-fetcher-settings',
            'hadith_fetcher_main_section'
        );
        
        add_settings_field(
            'fetch_delay',
            __('Fetch Delay (ms)', 'hadith-fetcher'),
            array($this, 'render_fetch_delay_field'),
            'hadith-fetcher-settings',
            'hadith_fetcher_main_section'
        );
        
        add_settings_field(
            'api_field_mapping',
            __('Field Mapping', 'hadith-fetcher'),
            array($this, 'render_field_mapping'),
            'hadith-fetcher-settings',
            'hadith_fetcher_main_section'
        );
    }
    
    /**
     * Sanitize settings before saving
     */
    public function sanitize_settings($input) {
        // Create clean output
        $output = array();
        
        // Sanitize default collection
        if (isset($input['default_collection'])) {
            $valid_collections = array('bukhari', 'muslim', 'abudawud', 'tirmidhi', 'nasai', 'ibnmajah', 'malik');
            $output['default_collection'] = in_array($input['default_collection'], $valid_collections) ? $input['default_collection'] : 'bukhari';
        }
        
        // Sanitize fetch delay
        if (isset($input['fetch_delay'])) {
            $output['fetch_delay'] = absint($input['fetch_delay']);
            if ($output['fetch_delay'] < 500) {
                $output['fetch_delay'] = 500; // Minimum 500ms delay
            }
        }
        
        // Sanitize field mappings
        if (isset($input['field_mapping']) && is_array($input['field_mapping'])) {
            $output['field_mapping'] = array();
            
            foreach ($input['field_mapping'] as $field_key => $field_value) {
                $field_key = sanitize_key($field_key);
                $field_value = sanitize_text_field($field_value);
                
                $output['field_mapping'][$field_key] = $field_value;
            }
        }
        
        // Sanitize custom field mappings
        if (isset($input['field_mapping_custom']) && is_array($input['field_mapping_custom'])) {
            $output['field_mapping_custom'] = array();
            
            foreach ($input['field_mapping_custom'] as $field_key => $field_value) {
                if (!empty($field_value)) {
                    $field_key = sanitize_key($field_key);
                    $field_value = sanitize_text_field($field_value);
                    
                    $output['field_mapping_custom'][$field_key] = $field_value;
                    
                    // If custom field is filled, override the main field_mapping value
                    if (isset($output['field_mapping'][$field_key]) && $output['field_mapping'][$field_key] === 'custom') {
                        $output['field_mapping'][$field_key] = $field_value;
                    }
                }
            }
        }
        
        return $output;
    }
    
    /**
     * Render settings section description
     */
    public function render_settings_section() {
        echo '<p>' . __('Configure the settings for Hadith Fetcher plugin.', 'hadith-fetcher') . '</p>';
    }
    
    /**
     * Render default collection field
     */
    public function render_default_collection_field() {
        $options = get_option('hadith_fetcher_options', array(
            'default_collection' => 'bukhari'
        ));
        
        ?>
        <select name="hadith_fetcher_options[default_collection]">
            <option value="bukhari" <?php selected($options['default_collection'], 'bukhari'); ?>><?php _e('Sahih al-Bukhari', 'hadith-fetcher'); ?></option>
            <option value="muslim" <?php selected($options['default_collection'], 'muslim'); ?>><?php _e('Sahih Muslim', 'hadith-fetcher'); ?></option>
            <option value="abudawud" <?php selected($options['default_collection'], 'abudawud'); ?>><?php _e('Sunan Abu Dawud', 'hadith-fetcher'); ?></option>
            <option value="tirmidhi" <?php selected($options['default_collection'], 'tirmidhi'); ?>><?php _e('Jami` at-Tirmidhi', 'hadith-fetcher'); ?></option>
            <option value="nasai" <?php selected($options['default_collection'], 'nasai'); ?>><?php _e('Sunan an-Nasa\'i', 'hadith-fetcher'); ?></option>
            <option value="ibnmajah" <?php selected($options['default_collection'], 'ibnmajah'); ?>><?php _e('Sunan Ibn Majah', 'hadith-fetcher'); ?></option>
            <option value="malik" <?php selected($options['default_collection'], 'malik'); ?>><?php _e('Muwatta Malik', 'hadith-fetcher'); ?></option>
        </select>
        <p class="description"><?php _e('Select the default hadith collection to use for fetching.', 'hadith-fetcher'); ?></p>
        <?php
    }
    
    /**
     * Render fetch delay field
     */
    public function render_fetch_delay_field() {
        $options = get_option('hadith_fetcher_options', array(
            'fetch_delay' => 1000
        ));
        
        ?>
        <input type="number" name="hadith_fetcher_options[fetch_delay]" value="<?php echo esc_attr($options['fetch_delay']); ?>" min="500" step="100" />
        <p class="description"><?php _e('Delay between API requests in milliseconds (for bulk imports). Minimum 500ms recommended.', 'hadith-fetcher'); ?></p>
        <?php
    }
    
    /**
     * Render field mapping
     */
    public function render_field_mapping() {
        $options = get_option('hadith_fetcher_options', array());
        
        // Set default field mappings if not set
        if (!isset($options['field_mapping']) || empty($options['field_mapping'])) {
            $options['field_mapping'] = array(
                'arabic_text' => '_hadith_arabic_text',
                'book_name' => '_hadith_book_name',
                'volume' => '_hadith_volume',
                'page' => '_hadith_page',
                'hadith_number' => '_hadith_number',
                'chapter_name' => '_hadith_chapter_name',
                'additional_info' => '_hadith_additional_info',
                'narrators' => '_hadith_chain_of_narrators',
                'english_translation' => '_hadith_english_default',
                'urdu_translation' => '_hadith_urdu_default',
                'bengali_translation' => '_hadith_bengali_default',
                'authenticity' => '_hadith_authenticity'
            );
            update_option('hadith_fetcher_options', $options);
        }
        
        // Get field mapping
        $field_mapping = $options['field_mapping'];
        
        // Fields to map
        $api_fields = array(
            'arabic_text' => __('Arabic Text', 'hadith-fetcher'),
            'book_name' => __('Book Name', 'hadith-fetcher'),
            'volume' => __('Volume', 'hadith-fetcher'),
            'page' => __('Page', 'hadith-fetcher'),
            'hadith_number' => __('Hadith Number', 'hadith-fetcher'),
            'chapter_name' => __('Chapter Name', 'hadith-fetcher'),
            'additional_info' => __('Additional Info', 'hadith-fetcher'),
            'narrators' => __('Narrators', 'hadith-fetcher'),
            'english_translation' => __('English Translation', 'hadith-fetcher'),
            'urdu_translation' => __('Urdu Translation', 'hadith-fetcher'),
            'bengali_translation' => __('Bengali Translation', 'hadith-fetcher'),
            'authenticity' => __('Authenticity', 'hadith-fetcher')
        );
        
        // Get all custom fields
        $custom_fields = $this->get_all_custom_fields();
        
        // Get ACF fields if available
        $acf_fields = array();
        if (function_exists('acf_get_field_groups')) {
            $field_groups = acf_get_field_groups();
            
            foreach ($field_groups as $field_group) {
                $fields = acf_get_fields($field_group);
                
                if (!empty($fields)) {
                    foreach ($fields as $field) {
                        $acf_fields[$field['key']] = array(
                            'name' => $field['name'],
                            'label' => $field['label'],
                            'type' => $field['type'],
                            'group' => $field_group['title']
                        );
                    }
                }
            }
        }
        
        ?>
        <table class="form-table field-mapping-table">
            <tr>
                <th><?php _e('API Field', 'hadith-fetcher'); ?></th>
                <th><?php _e('WordPress Field', 'hadith-fetcher'); ?></th>
                <th><?php _e('Custom Field Name', 'hadith-fetcher'); ?></th>
            </tr>
            <?php foreach ($api_fields as $field_key => $field_label) : 
                $current_value = isset($field_mapping[$field_key]) ? $field_mapping[$field_key] : '';
            ?>
                <tr>
                    <td><?php echo esc_html($field_label); ?></td>
                    <td>
                        <select name="hadith_fetcher_options[field_mapping][<?php echo esc_attr($field_key); ?>]" 
                                class="regular-text field-mapping-select" 
                                data-field="<?php echo esc_attr($field_key); ?>">
                            <option value=""><?php _e('-- Select Custom Field --', 'hadith-fetcher'); ?></option>
                            
                            <!-- Default WordPress meta options -->
                            <optgroup label="<?php _e('Default Meta Fields', 'hadith-fetcher'); ?>">
                                <option value="_hadith_arabic_text" <?php selected($current_value === '_hadith_arabic_text'); ?>><?php _e('Hadith Arabic Text', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_book_name" <?php selected($current_value === '_hadith_book_name'); ?>><?php _e('Hadith Book Name', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_volume" <?php selected($current_value === '_hadith_volume'); ?>><?php _e('Hadith Volume', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_page" <?php selected($current_value === '_hadith_page'); ?>><?php _e('Hadith Page', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_number" <?php selected($current_value === '_hadith_number'); ?>><?php _e('Hadith Number', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_chapter_name" <?php selected($current_value === '_hadith_chapter_name'); ?>><?php _e('Hadith Chapter Name', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_additional_info" <?php selected($current_value === '_hadith_additional_info'); ?>><?php _e('Hadith Additional Info', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_chain_of_narrators" <?php selected($current_value === '_hadith_chain_of_narrators'); ?>><?php _e('Hadith Chain of Narrators', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_english_default" <?php selected($current_value === '_hadith_english_default'); ?>><?php _e('Hadith English Translation', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_urdu_default" <?php selected($current_value === '_hadith_urdu_default'); ?>><?php _e('Hadith Urdu Translation', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_bengali_default" <?php selected($current_value === '_hadith_bengali_default'); ?>><?php _e('Hadith Bengali Translation', 'hadith-fetcher'); ?></option>
                                <option value="_hadith_authenticity" <?php selected($current_value === '_hadith_authenticity'); ?>><?php _e('Hadith Authenticity', 'hadith-fetcher'); ?></option>
                                <option value="custom" <?php selected(!in_array($current_value, ['', '_hadith_arabic_text', '_hadith_book_name', '_hadith_volume', '_hadith_page', '_hadith_number', '_hadith_chapter_name', '_hadith_additional_info', '_hadith_chain_of_narrators', '_hadith_english_default', '_hadith_urdu_default', '_hadith_bengali_default', '_hadith_authenticity']) && !isset($custom_fields[$current_value]) && !isset($acf_fields[$current_value])); ?>><?php _e('Custom Field (enter name →)', 'hadith-fetcher'); ?></option>
                            </optgroup>
                            
                            <?php if (!empty($custom_fields)) : ?>
                            <!-- Custom fields found in the system -->
                            <optgroup label="<?php _e('Custom Fields', 'hadith-fetcher'); ?>">
                                <?php foreach ($custom_fields as $meta_key => $meta_label) : ?>
                                    <option value="<?php echo esc_attr($meta_key); ?>" <?php selected($current_value === $meta_key); ?>><?php echo esc_html($meta_label); ?></option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endif; ?>
                            
                            <?php if (function_exists('acf_get_fields')) : ?>
                            <!-- ACF fields if available -->
                            <optgroup label="<?php _e('ACF Fields', 'hadith-fetcher'); ?>">
                                <?php 
                                $acf_fields = $this->get_acf_fields();
                                foreach ($acf_fields as $acf_key => $acf_label) : 
                                ?>
                                    <option value="<?php echo esc_attr($acf_key); ?>" <?php selected($current_value === $acf_key); ?>><?php echo esc_html($acf_label); ?></option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endif; ?>
                        </select>
                    </td>
                    <td>
                        <input type="text" 
                               class="regular-text custom-field-input" 
                               placeholder="<?php _e('Enter custom field name', 'hadith-fetcher'); ?>"
                               name="hadith_fetcher_options[field_mapping_custom][<?php echo esc_attr($field_key); ?>]"
                               value="<?php echo (!in_array($current_value, ['', '_hadith_arabic_text', '_hadith_book_name', '_hadith_volume', '_hadith_page', '_hadith_number', '_hadith_chapter_name', '_hadith_additional_info', '_hadith_chain_of_narrators', '_hadith_english_default', '_hadith_urdu_default', '_hadith_bengali_default', '_hadith_authenticity']) && !isset($custom_fields[$current_value]) && !isset($acf_fields[$current_value])) ? esc_attr($current_value) : ''; ?>"
                               data-field="<?php echo esc_attr($field_key); ?>"
                               <?php echo (!in_array($current_value, ['', '_hadith_arabic_text', '_hadith_book_name', '_hadith_volume', '_hadith_page', '_hadith_number', '_hadith_chapter_name', '_hadith_additional_info', '_hadith_chain_of_narrators', '_hadith_english_default', '_hadith_urdu_default', '_hadith_bengali_default', '_hadith_authenticity']) && !isset($custom_fields[$current_value]) && !isset($acf_fields[$current_value])) ? '' : 'style="display:none;"'; ?>>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <p class="description"><?php _e('Map API fields to your WordPress post meta fields. For ACF fields, use field keys.', 'hadith-fetcher'); ?></p>
        <p class="description"><?php _e('To use a custom field name not in the dropdown, select "Custom Field" and enter the name in the text box.', 'hadith-fetcher'); ?></p>
        <?php
    }
    
    /**
     * Get all custom fields in the system
     */
    private function get_all_custom_fields() {
        global $wpdb;
        
        // Get all meta keys from postmeta
        $meta_keys = $wpdb->get_col("
            SELECT DISTINCT pm.meta_key
            FROM {$wpdb->postmeta} pm
            LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE p.post_type = 'hadith'
            AND pm.meta_key NOT LIKE '\_%'
            ORDER BY pm.meta_key
        ");
        
        $custom_fields = array();
        foreach ($meta_keys as $meta_key) {
            if (!empty($meta_key)) {
                // Convert meta key to readable label
                $label = ucwords(str_replace('_', ' ', $meta_key));
                $custom_fields[$meta_key] = $label;
            }
        }
        
        return $custom_fields;
    }
    
    /**
     * Get ACF fields if available
     */
    private function get_acf_fields() {
        $acf_fields = array();
        
        if (function_exists('acf_get_field_groups')) {
            $field_groups = acf_get_field_groups(array('post_type' => 'hadith'));
            
            foreach ($field_groups as $field_group) {
                $fields = acf_get_fields($field_group);
                
                if (!empty($fields)) {
                    foreach ($fields as $field) {
                        $acf_fields[$field['key']] = $field['label'];
                    }
                }
            }
        }
        
        return $acf_fields;
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        // Only load assets on plugin pages
        if (strpos($hook, 'hadith-fetcher') === false) {
            return;
        }
        
        // Debug info
        error_log('Enqueuing Hadith Fetcher admin assets on hook: ' . $hook);
        
        // Enqueue styles
        wp_enqueue_style(
            'hadith-fetcher-admin',
            HADITH_FETCHER_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            HADITH_FETCHER_VERSION
        );
        
        // Enqueue scripts
        wp_enqueue_script(
            'hadith-fetcher-admin',
            HADITH_FETCHER_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            HADITH_FETCHER_VERSION,
            true
        );
        
        // Get fetch delay from options
        $options = get_option('hadith_fetcher_options', array('fetch_delay' => 1000));
        $fetch_delay = isset($options['fetch_delay']) ? intval($options['fetch_delay']) : 1000;
        
        // Generate a fresh nonce to ensure it's valid
        $nonce = wp_create_nonce('hadith_fetcher_nonce');
        
        // Localize script with data
        wp_localize_script(
            'hadith-fetcher-admin',
            'hadithFetcherAdmin',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => $nonce,
                'fetching_text' => __('Fetching hadith...', 'hadith-fetcher'),
                'error_text' => __('Error fetching hadith. Please try again.', 'hadith-fetcher'),
                'save_text' => __('Save Hadith', 'hadith-fetcher'),
                'saving_text' => __('Saving hadith...', 'hadith-fetcher'),
                'fetch_delay' => $fetch_delay,
                'debug' => WP_DEBUG
            )
        );
        
        // Add RTL support for Arabic and Urdu
        wp_enqueue_style(
            'hadith-fetcher-fonts',
            'https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic&family=Noto+Nastaliq+Urdu&family=Noto+Serif+Bengali&display=swap',
            array(),
            HADITH_FETCHER_VERSION
        );
    }
    
    /**
     * Render main admin page
     */
    public function render_main_page() {
        // Get collections
        $collections = array(
            'bukhari' => __('Sahih al-Bukhari', 'hadith-fetcher'),
            'muslim' => __('Sahih Muslim', 'hadith-fetcher'),
            'abudawud' => __('Sunan Abu Dawud', 'hadith-fetcher'),
            'tirmidhi' => __('Jami` at-Tirmidhi', 'hadith-fetcher'),
            'nasai' => __('Sunan an-Nasa\'i', 'hadith-fetcher'),
            'ibnmajah' => __('Sunan Ibn Majah', 'hadith-fetcher'),
            'malik' => __('Muwatta Malik', 'hadith-fetcher')
        );
        
        // Get default collection from settings
        $options = get_option('hadith_fetcher_options', array('default_collection' => 'bukhari'));
        $default_collection = isset($options['default_collection']) ? $options['default_collection'] : 'bukhari';
        
        ?>
        <div class="wrap" id="hadith-fetcher-admin">
            <h1><?php _e('Hadith Fetcher', 'hadith-fetcher'); ?></h1>
            
            <div class="hadith-fetcher-container">
                <div class="hadith-fetcher-form">
                    <h2><?php _e('Fetch a Hadith', 'hadith-fetcher'); ?></h2>
                    <p><?php _e('Use this form to fetch a hadith from sunnah.com.', 'hadith-fetcher'); ?></p>
                    
                    <div class="form-group">
                        <label for="hadith-collection"><?php _e('Collection', 'hadith-fetcher'); ?></label>
                        <select id="hadith-collection" class="regular-text">
                            <?php foreach ($collections as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($value, $default_collection); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="hadith-book"><?php _e('Book Number', 'hadith-fetcher'); ?></label>
                        <input type="number" id="hadith-book" min="1" class="small-text" value="1">
                        <p class="description"><?php _e('Enter the book number from sunnah.com.', 'hadith-fetcher'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="hadith-number"><?php _e('Hadith Number', 'hadith-fetcher'); ?></label>
                        <input type="number" id="hadith-number" min="1" class="small-text" value="1">
                        <p class="description"><?php _e('Enter the hadith number from sunnah.com.', 'hadith-fetcher'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <button id="fetch-hadith" class="button button-primary" type="button"><?php _e('Fetch Hadith', 'hadith-fetcher'); ?></button>
                        <div id="fetch-status" class="status-message" style="display: none;"></div>
                    </div>
                </div>
                
                <div id="hadith-preview" class="hadith-preview" style="display: none;"></div>
            </div>
            
            <div class="hadith-fetcher-instructions">
                <h3><?php _e('Instructions', 'hadith-fetcher'); ?></h3>
                <ol>
                    <li><?php _e('Select the hadith collection from the dropdown.', 'hadith-fetcher'); ?></li>
                    <li><?php _e('Enter the book number and hadith number from sunnah.com.', 'hadith-fetcher'); ?></li>
                    <li><?php _e('Click "Fetch Hadith" to retrieve the hadith.', 'hadith-fetcher'); ?></li>
                    <li><?php _e('Review the hadith preview and click "Save Hadith" to save it to your site.', 'hadith-fetcher'); ?></li>
                </ol>
                
                <p><?php _e('Example URL: https://sunnah.com/bukhari/1/1', 'hadith-fetcher'); ?></p>
                <p><?php _e('In this example, "bukhari" is the collection, "1" is the book number, and "1" is the hadith number.', 'hadith-fetcher'); ?></p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            console.log('Main page script initialized');
            
            // Direct binding for fetch button to ensure it works
            $('#fetch-hadith').off('click').on('click', function(e) {
                e.preventDefault();
                console.log('Fetch button clicked (inline handler)');
                
                const collection = $('#hadith-collection').val();
                const book = $('#hadith-book').val();
                const hadithNumber = $('#hadith-number').val();
                
                // Validate inputs
                if (!collection || !book || !hadithNumber) {
                    $('#fetch-status').removeClass('success error loading').addClass('error');
                    $('#fetch-status').html('Please fill in all fields').show();
                    return;
                }
                
                // Show loading status
                $('#fetch-status').removeClass('success error').addClass('loading');
                $('#fetch-status').html('Fetching hadith...').show();
                
                // Make the AJAX request
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'fetch_hadith',
                        nonce: '<?php echo wp_create_nonce('hadith_fetcher_nonce'); ?>',
                        collection: collection,
                        book: book,
                        hadith: hadithNumber,
                        preview_only: true
                    },
                    success: function(response) {
                        console.log('AJAX response received:', response);
                        if (response.success) {
                            $('#fetch-status').removeClass('loading error').addClass('success');
                            $('#fetch-status').html('Hadith fetched successfully!').show();
                            
                            // Show preview - this will be handled by the main admin.js
                            if (typeof showHadithPreview === 'function') {
                                showHadithPreview(response.data.data);
                            } else {
                                console.error('showHadithPreview function not found');
                            }
                        } else {
                            $('#fetch-status').removeClass('loading success').addClass('error');
                            $('#fetch-status').html(response.data.message || 'Unknown error').show();
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX error:', status, error);
                        $('#fetch-status').removeClass('loading success').addClass('error');
                        $('#fetch-status').html('Error: ' + status + ' - ' + error).show();
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render bulk import page
     */
    public function render_bulk_page() {
        // Get options
        $options = get_option('hadith_fetcher_options', array(
            'default_collection' => 'bukhari',
            'fetch_delay' => 1000
        ));
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <div class="hadith-fetcher-card">
                <h2><?php _e('Bulk Import Hadiths', 'hadith-fetcher'); ?></h2>
                <p><?php _e('Use this form to import multiple hadiths at once from sunnah.com', 'hadith-fetcher'); ?></p>
                
                <div class="form-group">
                    <label for="bulk-collection"><?php _e('Collection', 'hadith-fetcher'); ?></label>
                    <select id="bulk-collection" name="bulk-collection">
                        <option value="bukhari" <?php selected($options['default_collection'], 'bukhari'); ?>><?php _e('Sahih al-Bukhari', 'hadith-fetcher'); ?></option>
                        <option value="muslim" <?php selected($options['default_collection'], 'muslim'); ?>><?php _e('Sahih Muslim', 'hadith-fetcher'); ?></option>
                        <option value="abudawud" <?php selected($options['default_collection'], 'abudawud'); ?>><?php _e('Sunan Abu Dawud', 'hadith-fetcher'); ?></option>
                        <option value="tirmidhi" <?php selected($options['default_collection'], 'tirmidhi'); ?>><?php _e('Jami` at-Tirmidhi', 'hadith-fetcher'); ?></option>
                        <option value="nasai" <?php selected($options['default_collection'], 'nasai'); ?>><?php _e('Sunan an-Nasa\'i', 'hadith-fetcher'); ?></option>
                        <option value="ibnmajah" <?php selected($options['default_collection'], 'ibnmajah'); ?>><?php _e('Sunan Ibn Majah', 'hadith-fetcher'); ?></option>
                        <option value="malik" <?php selected($options['default_collection'], 'malik'); ?>><?php _e('Muwatta Malik', 'hadith-fetcher'); ?></option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="bulk-book"><?php _e('Book Number', 'hadith-fetcher'); ?></label>
                    <input type="number" id="bulk-book" name="bulk-book" min="1" value="1">
                </div>
                
                <div class="form-group">
                    <label for="bulk-start"><?php _e('Start Hadith Number', 'hadith-fetcher'); ?></label>
                    <input type="number" id="bulk-start" name="bulk-start" min="1" value="1">
                </div>
                
                <div class="form-group">
                    <label for="bulk-end"><?php _e('End Hadith Number', 'hadith-fetcher'); ?></label>
                    <input type="number" id="bulk-end" name="bulk-end" min="1" value="10">
                </div>
                
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="bulk-overwrite" name="bulk-overwrite" value="1">
                        <?php _e('Overwrite existing hadiths', 'hadith-fetcher'); ?>
                    </label>
                </div>
                
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="bulk-preview" name="bulk-preview" value="1" checked>
                        <?php _e('Show preview before saving each hadith', 'hadith-fetcher'); ?>
                    </label>
                </div>
                
                <div class="form-group">
                    <button id="bulk-fetch" class="button button-primary"><?php _e('Start Bulk Import', 'hadith-fetcher'); ?></button>
                </div>
                
                <div class="progress-container" style="display: none;">
                    <div class="progress-bar">
                        <div class="progress-fill"></div>
                    </div>
                    <div class="progress-text">0%</div>
                </div>
                
                <div id="bulk-status" class="fetch-status"></div>
                
                <div id="bulk-log" class="bulk-log"></div>
                
                <div id="bulk-hadith-preview" class="hadith-preview" style="display: none;"></div>
            </div>
        </div>
        
        <style>
        .progress-container {
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .progress-bar {
            width: 100%;
            height: 20px;
            background-color: #e5e5e5;
            border-radius: 4px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background-color: #2271b1;
            width: 0;
            transition: width 0.3s ease;
        }
        .progress-text {
            text-align: center;
            margin-top: 5px;
            font-size: 12px;
            color: #666;
        }
        .bulk-log {
            max-height: 200px;
            overflow-y: auto;
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            padding: 10px;
            font-family: monospace;
            margin-top: 15px;
            display: none;
        }
        .hadith-preview {
            margin-top: 30px;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .hadith-preview-arabic {
            direction: rtl;
            font-family: 'Noto Naskh Arabic', serif;
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f9f9f9;
        }
        .hadith-preview-english {
            margin-bottom: 20px;
        }
        .hadith-preview-urdu {
            direction: rtl;
            font-family: 'Noto Nastaliq Urdu', serif;
            font-size: 18px;
            line-height: 1.8;
            margin-bottom: 20px;
        }
        .hadith-preview-bengali {
            font-family: 'Noto Serif Bengali', serif;
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .preview-controls {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
        }
        .status-message {
            margin-top: 10px;
            padding: 10px;
            border-radius: 4px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .loading {
            background-color: #e9ecef;
            color: #495057;
            border: 1px solid #ced4da;
        }
        .loading:after {
            content: "...";
            animation: dots 1s steps(5, end) infinite;
        }
        @keyframes dots {
            0%, 20% { content: "."; }
            40% { content: ".."; }
            60%, 100% { content: "..."; }
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            console.log('Bulk import page script initialized');
            
            // Helper functions
            function showBulkStatus(type, message) {
                const $status = $('#bulk-status');
                $status.removeClass('success error loading').addClass(type);
                $status.html(message);
                $status.show();
            }
            
            function updateProgress(percent) {
                $('.progress-fill').css('width', percent + '%');
                $('.progress-text').text(percent + '%');
            }
            
            function appendToLog(message) {
                const timestamp = new Date().toLocaleTimeString();
                $('#bulk-log').append('[' + timestamp + '] ' + message + '<br>');
                $('#bulk-log').scrollTop($('#bulk-log')[0].scrollHeight);
            }
            
            // Process a single hadith in the bulk sequence
            function processNextHadith(collection, book, current, end, importedCount, failedCount, totalHadiths, overwrite, showPreview) {
                if (current > end) {
                    // All done
                    showBulkStatus('success', 'Bulk import completed. ' + importedCount + ' hadiths imported, ' + failedCount + ' failed.');
                    appendToLog('Bulk import completed. ' + importedCount + ' hadiths imported, ' + failedCount + ' failed.');
                    return;
                }
                
                // Update status
                showBulkStatus('loading', 'Processing hadith ' + current + ' of ' + end + '...');
                appendToLog('Processing hadith ' + current + '...');
                
                // Calculate progress
                const progress = Math.round(((current - (end - totalHadiths + 1) + 1) / totalHadiths) * 100);
                updateProgress(progress);
                
                // Send AJAX request
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'fetch_hadith',
                        nonce: '<?php echo wp_create_nonce('hadith_fetcher_nonce'); ?>',
                        collection: collection,
                        book: book,
                        hadith: current,
                        preview_only: showPreview
                    },
                    success: function(response) {
                        try {
                            console.log('AJAX response for hadith ' + current + ':', response);
                            
                            if (response.success) {
                                if (showPreview) {
                                    // Show preview and wait for user confirmation
                                    appendToLog('Showing preview for hadith ' + current + '...');
                                    
                                    // Display the hadith preview
                                    const $preview = $('#bulk-hadith-preview');
                                    
                                    // Create preview HTML with save and skip buttons
                                    let previewHtml = '<h3>Hadith Preview: ' + collection + '/' + book + '/' + current + '</h3>';
                                    
                                    // Add hadith content using showHadithPreview function if available
                                    if (typeof window.showHadithPreview === 'function') {
                                        // Use the default preview container first, then add our buttons
                                        window.showHadithPreview(response.data.data);
                                        
                                        // Add our controls to the preview container
                                        $('#hadith-preview').append('<div class="preview-controls">' + 
                                            '<button id="bulk-save-hadith" class="button button-primary">Save This Hadith</button> ' +
                                            '<button id="bulk-skip-hadith" class="button">Skip</button>' +
                                            '</div>');
                                        
                                        // Show the preview
                                        $('#hadith-preview').show();
                                        
                                        // Scroll to preview
                                        $('html, body').animate({
                                            scrollTop: $('#hadith-preview').offset().top - 100
                                        }, 500);
                                    } else {
                                        // Create basic preview
                                        previewHtml += '<div class="preview-content">';
                                        
                                        // Add Arabic text if available
                                        if (response.data.data.arabic_text) {
                                            previewHtml += '<div class="hadith-preview-arabic">';
                                            previewHtml += '<h4>Arabic Text</h4>';
                                            previewHtml += '<div class="arabic-text">' + response.data.data.arabic_text + '</div>';
                                            previewHtml += '</div>';
                                        }
                                        
                                        // Add English translation if available
                                        if (response.data.data.english_default) {
                                            previewHtml += '<div class="hadith-preview-english">';
                                            previewHtml += '<h4>English Translation</h4>';
                                            previewHtml += '<div class="english-text">' + response.data.data.english_default + '</div>';
                                            previewHtml += '</div>';
                                        }
                                        
                                        previewHtml += '</div>';
                                        
                                        // Add controls
                                        previewHtml += '<div class="preview-controls">';
                                        previewHtml += '<button id="bulk-save-hadith" class="button button-primary">Save This Hadith</button> ';
                                        previewHtml += '<button id="bulk-skip-hadith" class="button">Skip</button>';
                                        previewHtml += '</div>';
                                        
                                        $preview.html(previewHtml).show();
                                        
                                        // Scroll to preview
                                        $('html, body').animate({
                                            scrollTop: $preview.offset().top - 100
                                        }, 500);
                                    }
                                    
                                    // Save button click handler
                                    $(document).off('click', '#bulk-save-hadith').on('click', '#bulk-save-hadith', function() {
                                        // Hide preview
                                        $('#bulk-hadith-preview').hide();
                                        
                                        // Save the hadith
                                        appendToLog('Saving hadith ' + current + '...');
                                        
                                        $.ajax({
                                            url: '<?php echo admin_url('admin-ajax.php'); ?>',
                                            type: 'POST',
                                            data: {
                                                action: 'fetch_hadith',
                                                nonce: '<?php echo wp_create_nonce('hadith_fetcher_nonce'); ?>',
                                                collection: collection,
                                                book: book,
                                                hadith: current,
                                                preview_only: false,
                                                overwrite: overwrite ? 1 : 0
                                            },
                                            success: function(saveResponse) {
                                                if (saveResponse.success) {
                                                    importedCount++;
                                                    appendToLog('Success: Hadith ' + current + ' imported. ID: ' + saveResponse.data.post_id);
                                                } else {
                                                    failedCount++;
                                                    appendToLog('Error: Failed to import hadith ' + current + '. ' + saveResponse.data.message);
                                                }
                                                
                                                // Process next hadith
                                                setTimeout(function() {
                                                    processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite, showPreview);
                                                }, 500);
                                            },
                                            error: function(xhr, status, error) {
                                                failedCount++;
                                                appendToLog('Error: Failed to save hadith ' + current + '. Network error: ' + status);
                                                
                                                // Process next hadith
                                                setTimeout(function() {
                                                    processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite, showPreview);
                                                }, 500);
                                            }
                                        });
                                    });
                                    
                                    // Skip button click handler
                                    $(document).off('click', '#bulk-skip-hadith').on('click', '#bulk-skip-hadith', function() {
                                        // Hide preview
                                        $('#bulk-hadith-preview').hide();
                                        appendToLog('Skipped hadith ' + current);
                                        
                                        // Process next hadith
                                        setTimeout(function() {
                                            processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite, showPreview);
                                        }, 500);
                                    });
                                } else {
                                    // Automatic save without preview
                                    importedCount++;
                                    appendToLog('Success: Hadith ' + current + ' imported. ID: ' + response.data.post_id);
                                    
                                    // Process next hadith
                                    setTimeout(function() {
                                        processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite, showPreview);
                                    }, 500);
                                }
                            } else {
                                failedCount++;
                                appendToLog('Error: Failed to process hadith ' + current + '. ' + response.data.message);
                                
                                // Process next hadith
                                setTimeout(function() {
                                    processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite, showPreview);
                                }, 500);
                            }
                        } catch (err) {
                            console.error('Error processing hadith response:', err);
                            failedCount++;
                            appendToLog('Error: Failed to process hadith ' + current + ' response. ' + err.message);
                            
                            // Continue with next hadith
                            setTimeout(function() {
                                processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite, showPreview);
                            }, 500);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX error for hadith ' + current + ':', status, error);
                        failedCount++;
                        appendToLog('Error: Failed to process hadith ' + current + '. Network error: ' + status);
                        
                        // Process next hadith
                        setTimeout(function() {
                            processNextHadith(collection, book, current + 1, end, importedCount, failedCount, totalHadiths, overwrite, showPreview);
                        }, 500);
                    }
                });
            }
            
            // Direct binding for bulk fetch button to ensure it works
            $('#bulk-fetch').off('click').on('click', function(e) {
                e.preventDefault();
                console.log('Bulk fetch button clicked (inline handler)');
                
                const collection = $('#bulk-collection').val();
                const book = $('#bulk-book').val();
                const startHadith = parseInt($('#bulk-start').val());
                const endHadith = parseInt($('#bulk-end').val());
                const overwrite = $('#bulk-overwrite').is(':checked');
                const showPreview = $('#bulk-preview').is(':checked');
                
                console.log('Bulk import parameters:', {
                    collection,
                    book,
                    startHadith,
                    endHadith,
                    overwrite,
                    showPreview
                });
                
                // Validate inputs
                if (!collection || !book || isNaN(startHadith) || isNaN(endHadith)) {
                    showBulkStatus('error', 'Please fill in all fields');
                    return;
                }
                
                if (startHadith > endHadith) {
                    showBulkStatus('error', 'Start hadith number must be less than or equal to end hadith number');
                    return;
                }
                
                // Show progress bar
                $('.progress-container').show();
                updateProgress(0);
                
                // Show loading status
                showBulkStatus('loading', 'Starting bulk import...');
                
                // Show bulk log
                $('#bulk-log').empty().show();
                appendToLog('Starting bulk import of hadiths ' + startHadith + ' to ' + endHadith + ' from collection: ' + collection);
                
                // Start bulk import
                const totalHadiths = endHadith - startHadith + 1;
                let importedCount = 0;
                let failedCount = 0;
                
                // Process hadiths one by one
                processNextHadith(collection, book, startHadith, endHadith, importedCount, failedCount, totalHadiths, overwrite, showPreview);
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('hadith_fetcher_settings');
                do_settings_sections('hadith-fetcher-settings');
                submit_button();
                ?>
            </form>
            
            <div class="hadith-fetcher-card">
                <h2><?php _e('Export/Import Settings', 'hadith-fetcher'); ?></h2>
                
                <div class="export-section">
                    <h3><?php _e('Export Settings', 'hadith-fetcher'); ?></h3>
                    <p><?php _e('Export your current settings to use on another site.', 'hadith-fetcher'); ?></p>
                    <button id="export-settings" class="button"><?php _e('Export Settings', 'hadith-fetcher'); ?></button>
                </div>
                
                <div class="import-section">
                    <h3><?php _e('Import Settings', 'hadith-fetcher'); ?></h3>
                    <p><?php _e('Import settings from another site.', 'hadith-fetcher'); ?></p>
                    <textarea id="import-data" rows="5" class="large-text"></textarea>
                    <p><button id="import-settings" class="button"><?php _e('Import Settings', 'hadith-fetcher'); ?></button></p>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render custom fields page
     */
    public function render_fields_page() {
        // Get all custom fields
        global $wpdb;
        
        // Get all meta keys from posts
        $post_meta_keys = $wpdb->get_col("
            SELECT DISTINCT pm.meta_key
            FROM {$wpdb->postmeta} pm
            ORDER BY pm.meta_key
        ");
        
        // Get ACF fields if available
        $acf_fields = array();
        if (function_exists('acf_get_field_groups')) {
            $field_groups = acf_get_field_groups();
            
            foreach ($field_groups as $field_group) {
                $fields = acf_get_fields($field_group);
                
                if (!empty($fields)) {
                    foreach ($fields as $field) {
                        $acf_fields[$field['key']] = array(
                            'name' => $field['name'],
                            'label' => $field['label'],
                            'type' => $field['type'],
                            'group' => $field_group['title']
                        );
                    }
                }
            }
        }
        
        // Get options for field mapping
        $options = get_option('hadith_fetcher_options', array());
        $field_mapping = isset($options['field_mapping']) ? $options['field_mapping'] : array();
        
        // Organize fields into categories
        $system_fields = array();
        $meta_fields = array();
        
        foreach ($post_meta_keys as $key) {
            if (substr($key, 0, 1) === '_' && substr($key, 0, 6) !== '_hadith') {
                // This is a system field (usually hidden)
                $system_fields[] = $key;
            } else {
                // Regular meta field
                $meta_fields[] = $key;
            }
        }
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <div class="hadith-fetcher-card">
                <h2><?php _e('WordPress Custom Fields', 'hadith-fetcher'); ?></h2>
                <p><?php _e('This page shows all custom fields in your WordPress installation that can be used for mapping hadith data.', 'hadith-fetcher'); ?></p>
                
                <h3><?php _e('Current Field Mappings', 'hadith-fetcher'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Hadith Data', 'hadith-fetcher'); ?></th>
                            <th><?php _e('Mapped To', 'hadith-fetcher'); ?></th>
                            <th><?php _e('Field Type', 'hadith-fetcher'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $api_fields = array(
                            'arabic_text' => __('Arabic Text', 'hadith-fetcher'),
                            'book_name' => __('Book Name', 'hadith-fetcher'),
                            'volume' => __('Volume', 'hadith-fetcher'),
                            'page' => __('Page', 'hadith-fetcher'),
                            'hadith_number' => __('Hadith Number', 'hadith-fetcher'),
                            'chapter_name' => __('Chapter Name', 'hadith-fetcher'),
                            'additional_info' => __('Additional Info', 'hadith-fetcher'),
                            'narrators' => __('Narrators', 'hadith-fetcher'),
                            'english_translation' => __('English Translation', 'hadith-fetcher'),
                            'urdu_translation' => __('Urdu Translation', 'hadith-fetcher'),
                            'bengali_translation' => __('Bengali Translation', 'hadith-fetcher')
                        );
                        
                        foreach ($api_fields as $field_key => $field_label) :
                            $target_field = isset($field_mapping[$field_key]) ? $field_mapping[$field_key] : '';
                            $field_type = '';
                            
                            if (!empty($target_field)) {
                                if (isset($acf_fields[$target_field])) {
                                    $field_type = 'ACF: ' . $acf_fields[$target_field]['type'];
                                } elseif (in_array($target_field, $meta_fields)) {
                                    $field_type = 'Custom Field';
                                } elseif (in_array($target_field, $system_fields)) {
                                    $field_type = 'System Field';
                                } else {
                                    $field_type = 'Unknown';
                                }
                            }
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($field_label); ?></strong></td>
                                <td><?php echo !empty($target_field) ? esc_html($target_field) : '<em>' . __('Not mapped', 'hadith-fetcher') . '</em>'; ?></td>
                                <td><?php echo esc_html($field_type); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <p>
                    <a href="<?php echo admin_url('admin.php?page=hadith-fetcher-settings'); ?>" class="button button-primary">
                        <?php _e('Update Field Mappings', 'hadith-fetcher'); ?>
                    </a>
                </p>
                
                <h3><?php _e('Available Custom Fields', 'hadith-fetcher'); ?></h3>
                
                <div class="field-tabs">
                    <a href="#regular-fields" class="tab-link active"><?php _e('Regular Meta Fields', 'hadith-fetcher'); ?></a>
                    <a href="#system-fields" class="tab-link"><?php _e('System Fields', 'hadith-fetcher'); ?></a>
                    <?php if (!empty($acf_fields)) : ?>
                        <a href="#acf-fields" class="tab-link"><?php _e('ACF Fields', 'hadith-fetcher'); ?></a>
                    <?php endif; ?>
                </div>
                
                <div id="regular-fields" class="tab-content active">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Field Key', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Sample Value', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Used By', 'hadith-fetcher'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($meta_fields)) : ?>
                                <tr>
                                    <td colspan="3"><?php _e('No custom fields found.', 'hadith-fetcher'); ?></td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($meta_fields as $key) : 
                                    // Get sample value and post count
                                    $sample_value = $wpdb->get_var($wpdb->prepare(
                                        "SELECT pm.meta_value FROM {$wpdb->postmeta} pm WHERE pm.meta_key = %s LIMIT 1",
                                        $key
                                    ));
                                    
                                    $post_count = $wpdb->get_var($wpdb->prepare(
                                        "SELECT COUNT(DISTINCT pm.post_id) FROM {$wpdb->postmeta} pm WHERE pm.meta_key = %s",
                                        $key
                                    ));
                                    
                                    // Truncate long values
                                    if (strlen($sample_value) > 50) {
                                        $sample_value = substr($sample_value, 0, 47) . '...';
                                    }
                                ?>
                                    <tr>
                                        <td><code><?php echo esc_html($key); ?></code></td>
                                        <td><?php echo esc_html($sample_value); ?></td>
                                        <td><?php printf(_n('%s post', '%s posts', $post_count, 'hadith-fetcher'), number_format_i18n($post_count)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div id="system-fields" class="tab-content">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Field Key', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Sample Value', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Used By', 'hadith-fetcher'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($system_fields)) : ?>
                                <tr>
                                    <td colspan="3"><?php _e('No system fields found.', 'hadith-fetcher'); ?></td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($system_fields as $key) : 
                                    // Get sample value and post count
                                    $sample_value = $wpdb->get_var($wpdb->prepare(
                                        "SELECT pm.meta_value FROM {$wpdb->postmeta} pm WHERE pm.meta_key = %s LIMIT 1",
                                        $key
                                    ));
                                    
                                    $post_count = $wpdb->get_var($wpdb->prepare(
                                        "SELECT COUNT(DISTINCT pm.post_id) FROM {$wpdb->postmeta} pm WHERE pm.meta_key = %s",
                                        $key
                                    ));
                                    
                                    // Truncate long values
                                    if (strlen($sample_value) > 50) {
                                        $sample_value = substr($sample_value, 0, 47) . '...';
                                    }
                                ?>
                                    <tr>
                                        <td><code><?php echo esc_html($key); ?></code></td>
                                        <td><?php echo esc_html($sample_value); ?></td>
                                        <td><?php printf(_n('%s post', '%s posts', $post_count, 'hadith-fetcher'), number_format_i18n($post_count)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if (!empty($acf_fields)) : ?>
                <div id="acf-fields" class="tab-content">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Field Key', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Field Name', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Label', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Type', 'hadith-fetcher'); ?></th>
                                <th><?php _e('Field Group', 'hadith-fetcher'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($acf_fields as $key => $field) : ?>
                                <tr>
                                    <td><code><?php echo esc_html($key); ?></code></td>
                                    <td><?php echo esc_html($field['name']); ?></td>
                                    <td><?php echo esc_html($field['label']); ?></td>
                                    <td><?php echo esc_html($field['type']); ?></td>
                                    <td><?php echo esc_html($field['group']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                
                <div class="field-inspector">
                    <h3><?php _e('Field Inspector', 'hadith-fetcher'); ?></h3>
                    <p><?php _e('Enter a post ID to see all its custom fields.', 'hadith-fetcher'); ?></p>
                    
                    <div class="form-group">
                        <label for="post-id"><?php _e('Post ID', 'hadith-fetcher'); ?></label>
                        <input type="number" id="post-id" min="1" class="regular-text">
                        <button id="inspect-post" class="button"><?php _e('Inspect', 'hadith-fetcher'); ?></button>
                    </div>
                    
                    <div id="field-inspector-results"></div>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab functionality
            $('.tab-link').on('click', function(e) {
                e.preventDefault();
                
                // Update active tab
                $('.tab-link').removeClass('active');
                $(this).addClass('active');
                
                // Show the tab content
                $('.tab-content').removeClass('active');
                $($(this).attr('href')).addClass('active');
            });
            
            // Field inspector
            $('#inspect-post').on('click', function() {
                const postId = $('#post-id').val();
                
                if (!postId) {
                    $('#field-inspector-results').html('<p class="error"><?php _e('Please enter a valid post ID.', 'hadith-fetcher'); ?></p>');
                    return;
                }
                
                $('#field-inspector-results').html('<p><?php _e('Loading...', 'hadith-fetcher'); ?></p>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'inspect_post_fields',
                        post_id: postId,
                        nonce: '<?php echo wp_create_nonce('hadith_fetcher_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            let html = '';
                            
                            if (response.data.post) {
                                html += '<h4>' + response.data.post.post_title + ' (ID: ' + response.data.post.ID + ')</h4>';
                                
                                if (response.data.meta && response.data.meta.length > 0) {
                                    html += '<table class="wp-list-table widefat fixed striped">';
                                    html += '<thead><tr><th>Field Key</th><th>Value</th></tr></thead>';
                                    html += '<tbody>';
                                    
                                    $.each(response.data.meta, function(key, value) {
                                        html += '<tr>';
                                        html += '<td><code>' + key + '</code></td>';
                                        html += '<td>' + value + '</td>';
                                        html += '</tr>';
                                    });
                                    
                                    html += '</tbody></table>';
                                } else {
                                    html += '<p><?php _e('No custom fields found for this post.', 'hadith-fetcher'); ?></p>';
                                }
                            } else {
                                html += '<p class="error"><?php _e('Post not found.', 'hadith-fetcher'); ?></p>';
                            }
                            
                            $('#field-inspector-results').html(html);
                        } else {
                            $('#field-inspector-results').html('<p class="error">' + response.data.message + '</p>');
                        }
                    },
                    error: function() {
                        $('#field-inspector-results').html('<p class="error"><?php _e('An error occurred. Please try again.', 'hadith-fetcher'); ?></p>');
                    }
                });
            });
        });
        </script>
        
        <style>
        .field-tabs {
            margin: 20px 0 0;
            border-bottom: 1px solid #ccc;
            display: flex;
            overflow-x: auto;
        }
        .tab-link {
            padding: 10px 15px;
            text-decoration: none;
            color: #0073aa;
            display: inline-block;
            border: 1px solid transparent;
            border-bottom: none;
            margin-bottom: -1px;
            font-weight: 500;
        }
        .tab-link.active {
            background: #fff;
            border-color: #ccc;
            border-bottom-color: #fff;
            color: #444;
            font-weight: 600;
        }
        .tab-content {
            display: none;
            padding: 20px 0;
        }
        .tab-content.active {
            display: block;
        }
        .field-inspector {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        #field-inspector-results {
            margin-top: 20px;
        }
        .error {
            color: #d63638;
        }
        </style>
        <?php
    }
    
    /**
     * AJAX handler for fetching hadith
     */
    public function ajax_fetch_hadith() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hadith_fetcher_nonce')) {
            error_log('Hadith Fetcher: Nonce verification failed in ajax_fetch_hadith');
            wp_send_json_error(array('message' => __('Security check failed. Please refresh the page and try again.', 'hadith-fetcher')));
            return;
        }
        
        // Debug logging
        error_log('Hadith Fetcher: AJAX fetch_hadith called with data: ' . print_r($_POST, true));
        
        // Check parameters
        if (!isset($_POST['collection']) || !isset($_POST['book']) || !isset($_POST['hadith'])) {
            wp_send_json_error(array('message' => __('Missing required parameters', 'hadith-fetcher')));
            return;
        }
        
        // Get parameters
        $collection = sanitize_text_field($_POST['collection']);
        $book = sanitize_text_field($_POST['book']);
        $hadith_number = sanitize_text_field($_POST['hadith']);
        
        // Debug info
        error_log("Hadith Fetcher: Fetching hadith - Collection: $collection, Book: $book, Hadith: $hadith_number");
        
        // Check overwrite parameter
        $overwrite = isset($_POST['overwrite']) && $_POST['overwrite'] == 1;
        $preview_only = isset($_POST['preview_only']) && $_POST['preview_only'] == true;
        
        // Check if the hadith post type exists
        if (!post_type_exists('hadith')) {
            wp_send_json_error(array('message' => __('The "hadith" post type does not exist. Please make sure it is registered.', 'hadith-fetcher')));
            return;
        }
        
        // Check if database tables exist
        $database = new Hadith_Fetcher_Database();
        if (!$database->tables_exist()) {
            $database->check_tables();
            if (!$database->tables_exist()) {
                wp_send_json_error(array('message' => __('Could not create required database tables. Please check your database permissions.', 'hadith-fetcher')));
                return;
            }
        }
        
        try {
            // Fetch hadith
            $api = new Hadith_Fetcher_API();
            $hadith_data = $api->fetch_hadith($collection, $book, $hadith_number);
            
            if (is_wp_error($hadith_data)) {
                error_log('Hadith Fetcher API Error: ' . $hadith_data->get_error_message());
                wp_send_json_error(array('message' => $hadith_data->get_error_message()));
                return;
            }
            
            // Make sure we have some data
            if (empty($hadith_data) || !is_array($hadith_data)) {
                wp_send_json_error(array('message' => __('No data returned from API', 'hadith-fetcher')));
                return;
            }
            
            // Get the formatted JSON for display
            $formatted_json = $api->get_formatted_json($hadith_data);
            
            // Check if we should only return preview data
            if ($preview_only) {
                error_log('Hadith Fetcher: Returning preview data for hadith ' . $hadith_number);
                wp_send_json_success(array(
                    'message' => __('Hadith fetched successfully!', 'hadith-fetcher'),
                    'data' => $hadith_data,
                    'formatted_json' => $formatted_json
                ));
                return;
            }
            
            // Create or update hadith post
            $post_id = $api->create_hadith_post($hadith_data, $overwrite);
            
            if (is_wp_error($post_id)) {
                error_log('Hadith Fetcher Error: ' . $post_id->get_error_message());
                wp_send_json_error(array('message' => $post_id->get_error_message()));
                return;
            }
            
            // Get updated field data to confirm what was saved
            $saved_fields = array();
            
            // Check a few key fields to verify they were saved
            $key_fields = array(
                'hadith_arabic_text' => 'arabic_text',
                'hadith_number' => 'hadith_number'
            );
            
            foreach ($key_fields as $meta_key => $field_key) {
                $value = get_post_meta($post_id, $meta_key, true);
                $saved_fields[$field_key] = !empty($value);
            }
            
            // Check if custom table data was saved
            $db_data = $database->get_all_data($post_id);
            $saved_fields['reference'] = !empty($db_data['reference']);
            $saved_fields['narrators'] = !empty($db_data['narrators']);
            $saved_fields['translations'] = !empty($db_data['translations']);
            
            wp_send_json_success(array(
                'message' => __('Hadith fetched and saved successfully!', 'hadith-fetcher'),
                'post_id' => $post_id,
                'edit_url' => get_edit_post_link($post_id, 'raw'),
                'data' => $hadith_data,
                'formatted_json' => $formatted_json,
                'saved_fields' => $saved_fields,
                'custom_data' => $db_data
            ));
        } catch (Exception $e) {
            // Log the error
            error_log('Hadith Fetcher Error: ' . $e->getMessage());
            wp_send_json_error(array('message' => __('An error occurred: ', 'hadith-fetcher') . $e->getMessage()));
        }
    }
    
    /**
     * AJAX handler for exporting settings
     */
    public function ajax_export_settings() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hadith_fetcher_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'hadith-fetcher')));
        }
        
        // Get settings
        $settings = get_option('hadith_fetcher_options', array());
        
        // Send response
        wp_send_json_success(array(
            'settings' => $settings
        ));
    }
    
    /**
     * AJAX handler for importing settings
     */
    public function ajax_import_settings() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hadith_fetcher_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'hadith-fetcher')));
        }
        
        // Check settings data
        if (!isset($_POST['settings']) || !is_array($_POST['settings'])) {
            wp_send_json_error(array('message' => __('Invalid settings data', 'hadith-fetcher')));
        }
        
        // Update settings
        update_option('hadith_fetcher_options', $_POST['settings']);
        
        // Send response
        wp_send_json_success(array(
            'message' => __('Settings imported successfully', 'hadith-fetcher')
        ));
    }
    
    /**
     * AJAX handler for inspecting post fields
     */
    public function ajax_inspect_post_fields() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hadith_fetcher_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'hadith-fetcher')));
        }
        
        // Check post ID
        if (!isset($_POST['post_id']) || !is_numeric($_POST['post_id'])) {
            wp_send_json_error(array('message' => __('Invalid post ID', 'hadith-fetcher')));
        }
        
        $post_id = intval($_POST['post_id']);
        $post = get_post($post_id);
        
        if (!$post) {
            wp_send_json_error(array('message' => __('Post not found', 'hadith-fetcher')));
        }
        
        // Get post meta
        $post_meta = get_post_meta($post_id);
        $formatted_meta = array();
        
        foreach ($post_meta as $key => $values) {
            $value = $values[0];
            
            // Try to unserialize if needed
            if (is_serialized($value)) {
                $unserialized = @unserialize($value);
                if ($unserialized !== false) {
                    $value = '<pre>' . print_r($unserialized, true) . '</pre>';
                }
            }
            
            // Truncate long values
            if (is_string($value) && strlen($value) > 100 && strpos($value, '<pre>') !== 0) {
                $value = substr($value, 0, 97) . '...';
            }
            
            $formatted_meta[$key] = $value;
        }
        
        // Send response
        wp_send_json_success(array(
            'post' => array(
                'ID' => $post->ID,
                'post_title' => $post->post_title,
                'post_type' => $post->post_type,
                'post_status' => $post->post_status
            ),
            'meta' => $formatted_meta
        ));
    }
    
    /**
     * Initialize the admin functionality
     */
    public function init() {
        // Register admin hooks
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // AJAX handlers - modify to ensure proper registration
        add_action('wp_ajax_fetch_hadith', array($this, 'ajax_fetch_hadith'));
        add_action('wp_ajax_hadith_fetcher_export_settings', array($this, 'ajax_export_settings'));
        add_action('wp_ajax_hadith_fetcher_import_settings', array($this, 'ajax_import_settings'));
        add_action('wp_ajax_inspect_post_fields', array($this, 'ajax_inspect_post_fields'));
        
        // Add better error logging for debugging
        if (WP_DEBUG) {
            error_log('Hadith Fetcher Admin: Initialized with AJAX handlers registered');
        }
    }
}