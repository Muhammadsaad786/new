<?php
/**
 * API functionality for the Hadith Fetcher plugin
 */
class Hadith_Fetcher_API {
    /**
     * Base URL for sunnah.com
     */
    private $base_url = 'https://sunnah.com/';
    
    /**
     * Fetch a hadith from sunnah.com
     */
    public function fetch_hadith($collection, $book, $hadith_number) {
        // Construct URL
        $url = $this->base_url . $collection . '/' . $book . '/' . $hadith_number;
        
        // Fetch the page
        $response = wp_remote_get($url);
        
        // Check for errors
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Check response code
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            return new WP_Error(
                'invalid_response',
                sprintf(__('Invalid response code: %s', 'hadith-fetcher'), $response_code)
            );
        }
        
        // Get body
        $body = wp_remote_retrieve_body($response);
        
        // Parse the HTML
        return $this->parse_hadith_html($body, $collection, $book, $hadith_number);
    }
    
    /**
     * Parse the HTML from sunnah.com
     */
    private function parse_hadith_html($html, $collection, $book, $hadith_number) {
        // Initialize data array
        $hadith_data = array(
            'collection' => $collection,
            'book_number' => $book,
            'hadith_number' => $hadith_number,
            'book_name' => '',
            'volume' => '',
            'page' => '',
            'chapter_name' => '',
            'arabic_text' => '',
            'english_default' => '',
            'english_yusuf_ali' => '',
            'urdu_default' => '',
            'bengali_default' => '',
            'french_default' => '',
            'spanish_default' => '',
            'turkish_default' => '',
            'indonesian_default' => '',
            'additional_info' => '',
            'authenticity' => '',
            'narrators' => array()
        );
        
        // Debug info
        error_log("Hadith Fetcher: Parsing HTML for hadith - Collection: $collection, Book: $book, Hadith: $hadith_number");
        
        // Load HTML into DOMDocument
        $dom = new DOMDocument();
        
        // Suppress warnings for malformed HTML
        libxml_use_internal_errors(true);
        $dom->loadHTML($html);
        libxml_clear_errors();
        
        // Create XPath object
        $xpath = new DOMXPath($dom);
        
        // Get book name
        $book_name_node = $xpath->query('//div[contains(@class, "book_page_english_name")]');
        if ($book_name_node->length > 0) {
            $hadith_data['book_name'] = trim($book_name_node->item(0)->textContent);
            error_log("Hadith Fetcher: Found book name: " . $hadith_data['book_name']);
        }
        
        // Get hadith container
        $hadith_container = $xpath->query('//div[contains(@class, "hadith_container")]');
        
        if ($hadith_container->length === 0) {
            return new WP_Error(
                'parse_error',
                __('Could not find hadith container', 'hadith-fetcher')
            );
        }
        
        // Get Arabic text
        $arabic_node = $xpath->query('.//div[contains(@class, "arabic_hadith_full") or contains(@class, "arabic")]', $hadith_container->item(0));
        if ($arabic_node->length > 0) {
            $hadith_data['arabic_text'] = trim($arabic_node->item(0)->textContent);
            error_log("Hadith Fetcher: Found Arabic text with length: " . strlen($hadith_data['arabic_text']));
        }
        
        // Get English translation
        $english_node = $xpath->query('.//div[contains(@class, "text_details") or contains(@class, "english_translation") or contains(@class, "english") or contains(@lang, "en")]', $hadith_container->item(0));
        if ($english_node->length > 0) {
            $text = trim($english_node->item(0)->textContent);
            
            // Fix the formatting issues - remove unwanted slashes and fix line breaks
            $text = str_replace('/', '', $text);
            
            // Ensure we don't break lines after periods (fullstops) by replacing with proper spacing
            $text = preg_replace('/\.\s+/', '. ', $text);
            
            $hadith_data['english_default'] = $text;
            error_log("Hadith Fetcher: Found English text with length: " . strlen($hadith_data['english_default']));
        }
        
        // Get Urdu translation - enhanced selector based on language panel with additional selectors
        $urdu_selectors = array(
            // Try within the hadith container first
            './/div[contains(@class, "urdu_hadith_full")]',
            './/div[contains(@class, "urdu_translation")]',
            './/div[contains(@lang, "ur")]',
            './/div[contains(@class, "urduText")]',
            './/div[contains(@class, "lang-ur")]',
            './/div[contains(@data-lang, "urdu")]',
            './/div[contains(@class, "Urdu")]',
            './/div[contains(@class, "urdu")]',
            './/div[contains(@id, "urdu")]',
            './/div[@id="translationURLText"][@data-lang="urdu"]',
            
            // Also check for the language panel interface elements
            './/div[contains(@class, "translate_section")]/div[contains(@class, "urdu")]'
        );
        
        $urdu_text = '';
        foreach ($urdu_selectors as $selector) {
            $urdu_node = $xpath->query($selector, $hadith_container->item(0));
            if ($urdu_node->length > 0) {
                $urdu_text = trim($urdu_node->item(0)->textContent);
                if (!empty($urdu_text)) {
                    break;
                }
            }
        }
        
        // If still not found, try broader search outside the direct container
        if (empty($urdu_text)) {
            foreach ($urdu_selectors as $selector) {
                $selector_without_dot = ltrim($selector, '.');
                $urdu_node = $xpath->query('//' . substr($selector_without_dot, 2));
                if ($urdu_node->length > 0) {
                    $urdu_text = trim($urdu_node->item(0)->textContent);
                    if (!empty($urdu_text)) {
                        break;
                    }
                }
            }
        }
        
        // Try checking for language tabs or buttons
        if (empty($urdu_text)) {
            $language_tabs = $xpath->query('//a[contains(@class, "translation-tab") and contains(text(), "Urdu")]');
            if ($language_tabs->length > 0) {
                // If there's a tab for Urdu, try to find the corresponding content
                $tab_id = $language_tabs->item(0)->getAttribute('data-target') ?: $language_tabs->item(0)->getAttribute('href');
                if ($tab_id) {
                    $tab_id = ltrim($tab_id, '#');
                    $urdu_content = $xpath->query("//*[@id='$tab_id']");
                    if ($urdu_content->length > 0) {
                        $urdu_text = trim($urdu_content->item(0)->textContent);
                    }
                }
            }
        }
        
        if (!empty($urdu_text)) {
            $hadith_data['urdu_default'] = $urdu_text;
            error_log("Hadith Fetcher: Found Urdu text with length: " . strlen($hadith_data['urdu_default']));
        } else {
            error_log("Hadith Fetcher: Urdu text not found");
        }
        
        // Get Bengali translation - enhanced selector based on language panel with additional selectors
        $bengali_selectors = array(
            // Try within the hadith container first
            './/div[contains(@class, "bengali_hadith_full")]',
            './/div[contains(@class, "bengali_translation")]',
            './/div[contains(@lang, "bn")]',
            './/div[contains(@class, "bengaliText")]',
            './/div[contains(@class, "lang-bn")]',
            './/div[contains(@data-lang, "bangla")]',
            './/div[contains(@class, "Bangla")]',
            './/div[contains(@class, "bangla")]',
            './/div[contains(@class, "Bengali")]',
            './/div[contains(@class, "bengali")]',
            './/div[contains(@id, "bengali")]',
            './/div[@id="translationURLText"][@data-lang="bengali"]',
            
            // Also check for the language panel interface elements
            './/div[contains(@class, "translate_section")]/div[contains(@class, "bengali")]'
        );
        
        $bengali_text = '';
        foreach ($bengali_selectors as $selector) {
            $bengali_node = $xpath->query($selector, $hadith_container->item(0));
            if ($bengali_node->length > 0) {
                $bengali_text = trim($bengali_node->item(0)->textContent);
                if (!empty($bengali_text)) {
                    break;
                }
            }
        }
        
        // If still not found, try broader search outside the direct container
        if (empty($bengali_text)) {
            foreach ($bengali_selectors as $selector) {
                $selector_without_dot = ltrim($selector, '.');
                $bengali_node = $xpath->query('//' . substr($selector_without_dot, 2));
                if ($bengali_node->length > 0) {
                    $bengali_text = trim($bengali_node->item(0)->textContent);
                    if (!empty($bengali_text)) {
                        break;
                    }
                }
            }
        }
        
        // Try checking for language tabs or buttons
        if (empty($bengali_text)) {
            $language_tabs = $xpath->query('//a[contains(@class, "translation-tab") and (contains(text(), "Bengali") or contains(text(), "Bangla"))]');
            if ($language_tabs->length > 0) {
                // If there's a tab for Bengali, try to find the corresponding content
                $tab_id = $language_tabs->item(0)->getAttribute('data-target') ?: $language_tabs->item(0)->getAttribute('href');
                if ($tab_id) {
                    $tab_id = ltrim($tab_id, '#');
                    $bengali_content = $xpath->query("//*[@id='$tab_id']");
                    if ($bengali_content->length > 0) {
                        $bengali_text = trim($bengali_content->item(0)->textContent);
                    }
                }
            }
        }
        
        if (!empty($bengali_text)) {
            $hadith_data['bengali_default'] = $bengali_text;
            error_log("Hadith Fetcher: Found Bengali text with length: " . strlen($hadith_data['bengali_default']));
        } else {
            error_log("Hadith Fetcher: Bengali text not found");
        }
        
        // Get hadith reference info
        $reference_node = $xpath->query('.//table[contains(@class, "hadith_reference")]', $hadith_container->item(0));
        if ($reference_node->length > 0) {
            // Process reference table rows
            $rows = $xpath->query('.//tr', $reference_node->item(0));
            
            foreach ($rows as $row) {
                $cells = $xpath->query('.//td', $row);
                
                if ($cells->length >= 2) {
                    $key = trim($cells->item(0)->textContent);
                    $value = trim($cells->item(1)->textContent);
                    
                    error_log("Hadith Fetcher: Found reference row - Key: $key, Value: $value");
                    
                    if (stripos($key, 'Reference') !== false) {
                        $hadith_data['additional_info'] .= "Reference: $value\n";
                        
                        // Extract the hadith number from the reference using more robust pattern
                        // This will extract the last number from the reference string
                        if (preg_match('/(\d+)(?:\s*)$/', $value, $matches)) {
                            // Store the extracted hadith number
                            $hadith_data['hadith_number'] = $matches[1];
                            error_log('Hadith Fetcher: Extracted hadith number ' . $matches[1] . ' from reference: ' . $value);
                        } else {
                            error_log('Hadith Fetcher: Failed to extract hadith number from reference: ' . $value);
                        }
                    } elseif (stripos($key, 'In-book reference') !== false) {
                        // Store the full in-book reference in additional_info
                        $hadith_data['additional_info'] .= "In-book reference: $value\n";
                        
                        // Still parse book reference for book_number and other information
                        if (preg_match('/Book (\d+), Hadith (\d+)/', $value, $matches)) {
                            $hadith_data['book_number'] = $matches[1];
                            error_log('Hadith Fetcher: Extracted book number ' . $matches[1] . ' from in-book reference: ' . $value);
                            // We don't override hadith_number here anymore
                        }
                    } elseif (stripos($key, 'USC-MSA web') !== false) {
                        // Store the full USC-MSA reference in additional_info
                        $hadith_data['additional_info'] .= "USC-MSA web reference: $value\n";
                        
                        // Parse volume and book reference
                        if (preg_match('/Vol. (\d+), Book (\d+), Hadith (\d+)/', $value, $matches)) {
                            $hadith_data['volume'] = $matches[1];
                            // Only set book_number if it's not already set
                            if (empty($hadith_data['book_number'])) {
                                $hadith_data['book_number'] = $matches[2];
                                error_log('Hadith Fetcher: Extracted book number ' . $matches[2] . ' from USC-MSA reference: ' . $value);
                            }
                            // We don't override hadith_number here
                        }
                    } elseif (stripos($key, 'Grade') !== false) {
                        $hadith_data['authenticity'] = $value;
                        $hadith_data['additional_info'] .= "Grade: $value\n";
                        error_log('Hadith Fetcher: Extracted authenticity grade: ' . $value);
                    } else {
                        // Store any other reference information we find
                        $hadith_data['additional_info'] .= "$key: $value\n";
                    }
                }
            }
        } else {
            error_log("Hadith Fetcher: No reference table found");
            
            // If no reference table is found, try to extract reference info from other elements
            $reference_div = $xpath->query('//div[contains(@class, "hadith_reference_info") or contains(@class, "reference_info")]');
            if ($reference_div->length > 0) {
                $reference_text = trim($reference_div->item(0)->textContent);
                $hadith_data['additional_info'] .= "Reference Info: $reference_text\n";
                error_log('Hadith Fetcher: Found reference info outside of table: ' . $reference_text);
                
                // Try to extract book number
                if (preg_match('/Book (\d+)/', $reference_text, $matches)) {
                    $hadith_data['book_number'] = $matches[1];
                    error_log('Hadith Fetcher: Extracted book number ' . $matches[1] . ' from reference div');
                }
            }
        }
        
        // Get narrators (chain of narration)
        $narrators_node = $xpath->query('.//div[contains(@class, "hadith_narrated")]', $hadith_container->item(0));
        if ($narrators_node->length > 0) {
            $narration_text = trim($narrators_node->item(0)->textContent);
            
            // Extract narrators from the text
            if (preg_match('/Narrated (.+?):/i', $narration_text, $matches)) {
                $narrator_string = $matches[1];
                
                // Split by common separators
                $narrators = preg_split('/(,|\sand\s)/i', $narrator_string);
                
                foreach ($narrators as $narrator) {
                    $narrator = trim($narrator);
                    if (!empty($narrator)) {
                        $hadith_data['narrators'][] = $narrator;
                    }
                }
                
                error_log('Hadith Fetcher: Extracted ' . count($hadith_data['narrators']) . ' narrators from narration text');
            }
        }
        
        // Get chapter name
        $chapter_node = $xpath->query('//div[contains(@class, "chapter")]');
        if ($chapter_node->length > 0) {
            $hadith_data['chapter_name'] = trim($chapter_node->item(0)->textContent);
            error_log('Hadith Fetcher: Found chapter name: ' . $hadith_data['chapter_name']);
        }
        
        // Final debug info
        error_log('Hadith Fetcher: Completed parsing hadith ' . $hadith_number . ' from collection ' . $collection);
        
        return $hadith_data;
    }
    
    /**
     * Create or update hadith post
     */
    public function create_hadith_post($hadith_data, $overwrite = false) {
        // Check if the hadith post type exists
        if (!post_type_exists('hadith')) {
            return new WP_Error('post_type_missing', __('The "hadith" post type does not exist. Please make sure it is registered.', 'hadith-fetcher'));
        }
        
        // Ensure we have a valid hadith number
        if (empty($hadith_data['hadith_number'])) {
            return new WP_Error('missing_hadith_number', __('No hadith number found in the data.', 'hadith-fetcher'));
        }
        
        // Format the data according to the required JSON structure
        $formatted_data = $this->format_hadith_data($hadith_data);
        
        // Debug log
        error_log('Hadith Fetcher: Creating post for hadith number ' . $hadith_data['hadith_number'] . ' from collection ' . $hadith_data['collection']);
        
        // Check if hadith already exists
        $existing_posts = get_posts(array(
            'post_type' => 'hadith',
            'meta_query' => array(
                array(
                    'key' => 'hadith_number',
                    'value' => $hadith_data['hadith_number'],
                    'compare' => '='
                ),
                array(
                    'key' => 'hadith_collection',
                    'value' => $hadith_data['collection'],
                    'compare' => '='
                )
            ),
            'posts_per_page' => 1
        ));
        
        // Set up post data
        $post_data = $formatted_data['post'];
        
        // Update existing post or create new one
        if (!empty($existing_posts)) {
            // If overwrite is false and post exists, return existing post ID
            if (!$overwrite) {
                error_log('Hadith Fetcher: Using existing post ID ' . $existing_posts[0]->ID);
                return $existing_posts[0]->ID;
            }
            
            $post_data['ID'] = $existing_posts[0]->ID;
            $post_id = wp_update_post($post_data);
            error_log('Hadith Fetcher: Updated post ID ' . $post_id);
        } else {
            $post_id = wp_insert_post($post_data);
            error_log('Hadith Fetcher: Created new post ID ' . $post_id);
        }
        
        // Check for errors
        if (is_wp_error($post_id)) {
            error_log('Hadith Fetcher Error: ' . $post_id->get_error_message());
            return $post_id;
        }
        
        // Initialize the database class
        $database = new Hadith_Fetcher_Database();
        
        // Save meta fields (only the fields that use standard post meta)
        foreach ($formatted_data['meta'] as $meta_key => $meta_value) {
            update_post_meta($post_id, $meta_key, $meta_value);
            error_log('Hadith Fetcher: Updated meta ' . $meta_key . ' for post ID ' . $post_id);
        }
        
        // Save reference data to custom table
        if (!empty($formatted_data['reference'])) {
            $success = $database->save_reference($post_id, $formatted_data['reference']);
            error_log('Hadith Fetcher: Saved reference data for post ID ' . $post_id . ': ' . ($success ? 'success' : 'failed'));
        }
        
        // Delete existing narrators before adding new ones
        $database->delete_narrators($post_id);
        
        // Save narrators to custom table
        if (!empty($formatted_data['narrators'])) {
            foreach ($formatted_data['narrators'] as $narrator) {
                $database->save_narrator(
                    $post_id,
                    $narrator['narrator_name'],
                    $narrator['narrator_info'],
                    $narrator['position']
                );
            }
        }
        
        // Delete existing translations before adding new ones
        $database->delete_translations($post_id);
        
        // Save translations to custom table
        if (!empty($formatted_data['translations'])) {
            foreach ($formatted_data['translations'] as $translation) {
                $database->save_translation(
                    $post_id,
                    $translation['scholar_id'],
                    $translation['language_code'],
                    $translation['translation_text']
                );
            }
        }
        
        // Set taxonomies if they exist
        $taxonomies_to_set = array(
            'authenticity' => $hadith_data['authenticity'],
            'narrators' => $hadith_data['narrators']
        );
        
        // First, ensure the collection exists as a parent term in books taxonomy
        $collection_name = $this->getCollectionName($hadith_data['collection']);
        if (taxonomy_exists('books') && !empty($collection_name)) {
            // Check if collection term exists
            $collection_term = term_exists($collection_name, 'books');
            if (!$collection_term) {
                // Create collection as parent term
                $collection_term = wp_insert_term($collection_name, 'books');
            }
            
            // Get the collection term ID if successful
            $collection_term_id = is_wp_error($collection_term) ? 0 : $collection_term['term_id'];
            
            // Now handle the book name as a child term of the collection
            if ($collection_term_id && !empty($hadith_data['book_name'])) {
                // Check if book term exists as child of collection
                $book_term = term_exists($hadith_data['book_name'], 'books', $collection_term_id);
                if (!$book_term) {
                    // Create book as child term of collection
                    $book_term = wp_insert_term(
                        $hadith_data['book_name'], 
                        'books', 
                        array('parent' => $collection_term_id)
                    );
                }
                
                // Get the book term ID
                $book_term_id = is_wp_error($book_term) ? 0 : $book_term['term_id'];
                
                // Add chapter as a child term of book if it exists
                if ($book_term_id && !empty($hadith_data['chapter_name'])) {
                    // Check if chapter term already exists
                    $chapter_term = term_exists($hadith_data['chapter_name'], 'books', $book_term_id);
                    
                    // Only use existing chapter terms, don't create new ones
                    $chapter_term_id = is_wp_error($chapter_term) ? 0 : ($chapter_term ? $chapter_term['term_id'] : 0);
                    
                    // Collect all term IDs to assign
                    $term_ids = array();
                    if ($collection_term_id) $term_ids[] = (int)$collection_term_id;
                    if ($book_term_id) $term_ids[] = (int)$book_term_id;
                    if ($chapter_term_id) $term_ids[] = (int)$chapter_term_id;
                    
                    // Assign all terms in the hierarchy, not just the leaf node
                    if (!empty($term_ids)) {
                        wp_set_object_terms($post_id, $term_ids, 'books');
                    }
                } else if ($book_term_id) {
                    // If no chapter, set collection and book terms
                    wp_set_object_terms($post_id, array((int)$collection_term_id, (int)$book_term_id), 'books');
                }
            } else if ($collection_term_id) {
                // If no book name, set just the collection term
                wp_set_object_terms($post_id, array((int)$collection_term_id), 'books');
            }
        }
        
        // Process other taxonomies
        foreach ($taxonomies_to_set as $taxonomy => $terms) {
            if (taxonomy_exists($taxonomy)) {
                if (is_array($terms)) {
                    $term_ids = array();
                    foreach ($terms as $term) {
                        if (empty($term)) continue;
                        
                        $term_obj = term_exists($term, $taxonomy);
                        if (!$term_obj) {
                            $term_obj = wp_insert_term($term, $taxonomy);
                        }
                        
                        if (!is_wp_error($term_obj)) {
                            $term_ids[] = intval($term_obj['term_id']);
                        }
                    }
                    
                    if (!empty($term_ids)) {
                        wp_set_object_terms($post_id, $term_ids, $taxonomy);
                    }
                } else {
                    if (!empty($terms)) {
                        $term = term_exists($terms, $taxonomy);
                        if (!$term) {
                            $term = wp_insert_term($terms, $taxonomy);
                        }
                        
                        if (!is_wp_error($term)) {
                            wp_set_object_terms($post_id, intval($term['term_id']), $taxonomy);
                        }
                    }
                }
            }
        }
        
        return $post_id;
    }
    
    /**
     * Format hadith data according to the required JSON structure
     */
    public function format_hadith_data($hadith_data) {
        // Create the formatted data structure
        $formatted_data = array(
            'post' => array(
                'post_title' => sprintf(
                    __('Hadith %s - %s', 'hadith-fetcher'),
                    $hadith_data['hadith_number'],
                    $hadith_data['book_name']
                ),
                'post_status' => 'publish',
                'post_type' => 'hadith'
            ),
            'meta' => array(
                'hadith_arabic_text' => $hadith_data['arabic_text'],
                'hadith_collection' => $hadith_data['collection'],
                'hadith_book' => $hadith_data['book_number'],
                'hadith_number' => $hadith_data['hadith_number']
                // Removed chapter_name as requested since it's already in taxonomies
            ),
            'reference' => array(
                'book_name' => $hadith_data['book_name'],
                'volume_number' => $hadith_data['volume'],
                'page_number' => $hadith_data['page'],
                'hadith_number' => $hadith_data['hadith_number'],
                'authenticity_grade' => $hadith_data['authenticity'],
                'additional_reference' => $hadith_data['additional_info']
            ),
            'narrators' => array(),
            'translations' => array()
        );
        
        // Process narrators
        if (!empty($hadith_data['narrators']) && is_array($hadith_data['narrators'])) {
            $position = 1;
            foreach ($hadith_data['narrators'] as $narrator) {
                $formatted_data['narrators'][] = array(
                    'narrator_name' => $narrator,
                    'narrator_info' => '', // We don't have this info from the API
                    'position' => $position++
                );
            }
        }
        
        // Process translations - clean text before adding
        $translations = array(
            'en' => $this->clean_text($hadith_data['english_default']),
            'ur' => $hadith_data['urdu_default'],
            'bn' => $hadith_data['bengali_default'],
            'fr' => isset($hadith_data['french_default']) ? $hadith_data['french_default'] : '',
            'es' => isset($hadith_data['spanish_default']) ? $hadith_data['spanish_default'] : '',
            'tr' => isset($hadith_data['turkish_default']) ? $hadith_data['turkish_default'] : '',
            'id' => isset($hadith_data['indonesian_default']) ? $hadith_data['indonesian_default'] : ''
        );
        
        $scholar_id = 1; // Default scholar ID
        foreach ($translations as $lang_code => $translation_text) {
            if (!empty($translation_text)) {
                $formatted_data['translations'][] = array(
                    'language_code' => $lang_code,
                    'scholar_id' => $scholar_id,
                    'translation_text' => $translation_text
                );
            }
        }
        
        return $formatted_data;
    }
    
    /**
     * Clean text formatting
     * 
     * @param string $text Text to clean
     * @return string Cleaned text
     */
    private function clean_text($text) {
        if (empty($text)) {
            return '';
        }
        
        // Remove unwanted slashes
        $text = str_replace('/', '', $text);
        
        // Fix line breaks after periods by ensuring proper spacing
        $text = preg_replace('/\.\s+/', '. ', $text);
        
        // Remove excess whitespace
        $text = preg_replace('/\s+/', ' ', $text);
        
        // Trim whitespace from beginning and end
        $text = trim($text);
        
        return $text;
    }
    
    /**
     * Get formatted JSON for display
     * 
     * @param array $hadith_data Raw hadith data
     * @return string Formatted JSON string
     */
    public function get_formatted_json($hadith_data) {
        // Format the data
        $formatted_data = $this->format_hadith_data($hadith_data);
        
        // This is the JSON structure that corresponds to our database structure
        $json_structure = array(
            'post' => $formatted_data['post'],
            'meta' => $formatted_data['meta'],
            'reference' => $formatted_data['reference'],
            'narrators' => $formatted_data['narrators'],
            'translations' => $formatted_data['translations']
        );
        
        // Return formatted JSON
        return json_encode($json_structure, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * Save field data to post meta or ACF field
     */
    private function save_field($post_id, $field_key, $value) {
        if (empty($field_key) || $value === '') {
            return;
        }
        
        // Check if this is an ACF field
        if (function_exists('update_field') && strpos($field_key, 'field_') === 0) {
            // For ACF fields
            update_field($field_key, $value, $post_id);
        } else {
            // For standard WordPress meta fields
            update_post_meta($post_id, $field_key, $value);
        }
    }
    
    /**
     * Convert collection slug to full collection name
     * 
     * @param string $collection_slug The collection slug
     * @return string The full collection name
     */
    private function getCollectionName($collection_slug) {
        $collections = array(
            'bukhari' => 'Sahih al-Bukhari',
            'muslim' => 'Sahih Muslim',
            'abudawud' => 'Sunan Abu Dawud',
            'tirmidhi' => 'Jami` at-Tirmidhi',
            'nasai' => 'Sunan an-Nasa\'i',
            'ibnmajah' => 'Sunan Ibn Majah',
            'malik' => 'Muwatta Malik'
        );
        
        return isset($collections[$collection_slug]) ? $collections[$collection_slug] : $collection_slug;
    }
} 