<?php
/**
 * Database handling for the Hadith Fetcher plugin
 * Handles all database operations for custom tables
 */
class Hadith_Fetcher_Database {
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->references_table = $wpdb->prefix . 'hadith_references';
        $this->narrators_table = $wpdb->prefix . 'hadith_narrators';
        $this->translations_table = $wpdb->prefix . 'hadith_translations';
    }
    
    /**
     * Save reference data to the references table
     * 
     * @param int $post_id The post ID
     * @param array $reference The reference data
     * @return bool Success or failure
     */
    public function save_reference($post_id, $reference) {
        global $wpdb;
        
        // Delete existing reference data for this post
        $wpdb->delete(
            $this->references_table,
            array('post_id' => $post_id),
            array('%d')
        );
        
        // Insert new reference data
        $result = $wpdb->insert(
            $this->references_table,
            array(
                'post_id' => $post_id,
                'book_name' => isset($reference['book_name']) ? $reference['book_name'] : '',
                'volume_number' => isset($reference['volume_number']) ? $reference['volume_number'] : '',
                'page_number' => isset($reference['page_number']) ? $reference['page_number'] : '',
                'hadith_number' => isset($reference['hadith_number']) ? $reference['hadith_number'] : '',
                'authenticity_grade' => isset($reference['authenticity_grade']) ? $reference['authenticity_grade'] : '',
                'additional_reference' => isset($reference['additional_reference']) ? $reference['additional_reference'] : ''
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        return ($result !== false);
    }
    
    /**
     * Save narrator data to the narrators table
     * 
     * @param int $post_id The post ID
     * @param string $narrator_name The narrator name
     * @param string $narrator_info The narrator info
     * @param int $position The position in the chain
     * @return bool Success or failure
     */
    public function save_narrator($post_id, $narrator_name, $narrator_info, $position) {
        global $wpdb;
        
        // Insert narrator data
        $result = $wpdb->insert(
            $this->narrators_table,
            array(
                'post_id' => $post_id,
                'narrator_name' => $narrator_name,
                'narrator_info' => $narrator_info,
                'position' => $position
            ),
            array('%d', '%s', '%s', '%d')
        );
        
        return ($result !== false);
    }
    
    /**
     * Save translation data to the translations table
     * 
     * @param int $post_id The post ID
     * @param int $scholar_id The scholar ID
     * @param string $language_code The language code
     * @param string $translation_text The translation text
     * @return bool Success or failure
     */
    public function save_translation($post_id, $scholar_id, $language_code, $translation_text) {
        global $wpdb;
        
        // Insert translation data
        $result = $wpdb->insert(
            $this->translations_table,
            array(
                'post_id' => $post_id,
                'scholar_id' => $scholar_id,
                'language_code' => $language_code,
                'translation_text' => $translation_text
            ),
            array('%d', '%d', '%s', '%s')
        );
        
        return ($result !== false);
    }
    
    /**
     * Delete all narrators for a post
     * 
     * @param int $post_id The post ID
     * @return int|false The number of rows deleted, or false on error
     */
    public function delete_narrators($post_id) {
        global $wpdb;
        
        return $wpdb->delete(
            $this->narrators_table,
            array('post_id' => $post_id),
            array('%d')
        );
    }
    
    /**
     * Delete all translations for a post
     * 
     * @param int $post_id The post ID
     * @return int|false The number of rows deleted, or false on error
     */
    public function delete_translations($post_id) {
        global $wpdb;
        
        return $wpdb->delete(
            $this->translations_table,
            array('post_id' => $post_id),
            array('%d')
        );
    }
    
    /**
     * Check if tables exist and create them if they don't
     */
    public function check_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $references_table = "CREATE TABLE {$this->references_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            book_name varchar(255) NOT NULL,
            volume_number varchar(50) DEFAULT '',
            page_number varchar(50) DEFAULT '',
            hadith_number varchar(50) DEFAULT '',
            authenticity_grade varchar(100) DEFAULT '',
            additional_reference text DEFAULT '',
            PRIMARY KEY  (id),
            KEY post_id (post_id)
        ) $charset_collate;";
        
        $narrators_table = "CREATE TABLE {$this->narrators_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            narrator_name varchar(255) NOT NULL,
            narrator_info text DEFAULT '',
            position int(11) NOT NULL DEFAULT 1,
            PRIMARY KEY  (id),
            KEY post_id (post_id)
        ) $charset_collate;";
        
        $translations_table = "CREATE TABLE {$this->translations_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            scholar_id bigint(20) NOT NULL,
            language_code varchar(10) NOT NULL,
            translation_text text NOT NULL,
            PRIMARY KEY  (id),
            KEY post_id (post_id),
            KEY language_code (language_code)
        ) $charset_collate;";
        
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        
        dbDelta( $references_table );
        dbDelta( $narrators_table );
        dbDelta( $translations_table );
    }
    
    /**
     * Check if database tables exist
     * 
     * @return bool True if all tables exist, false otherwise
     */
    public function tables_exist() {
        global $wpdb;
        
        $references_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->references_table}'") === $this->references_table;
        $narrators_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->narrators_table}'") === $this->narrators_table;
        $translations_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->translations_table}'") === $this->translations_table;
        
        return $references_exists && $narrators_exists && $translations_exists;
    }
    
    /**
     * Get reference data for a post
     * 
     * @param int $post_id The post ID
     * @return array|false Reference data or false if not found
     */
    public function get_reference($post_id) {
        global $wpdb;
        
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->references_table} WHERE post_id = %d", $post_id),
            ARRAY_A
        );
    }
    
    /**
     * Get narrators for a post
     * 
     * @param int $post_id The post ID
     * @return array Narrator data
     */
    public function get_narrators($post_id) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->narrators_table} WHERE post_id = %d ORDER BY position ASC", $post_id),
            ARRAY_A
        );
    }
    
    /**
     * Get translations for a post
     * 
     * @param int $post_id The post ID
     * @return array Translation data
     */
    public function get_translations($post_id) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->translations_table} WHERE post_id = %d", $post_id),
            ARRAY_A
        );
    }
    
    /**
     * Get all data for a post in a structured format
     * 
     * @param int $post_id The post ID
     * @return array All data for the post
     */
    public function get_all_data($post_id) {
        $reference = $this->get_reference($post_id);
        $narrators = $this->get_narrators($post_id);
        $translations = $this->get_translations($post_id);
        
        return array(
            'reference' => $reference ?: array(),
            'narrators' => $narrators ?: array(),
            'translations' => $translations ?: array()
        );
    }
    
    /**
     * Save hadith reference to custom table
     * 
     * @param int $post_id The post ID
     * @param array $reference_data Reference data
     * @return bool True on success, false on failure
     */
    public function save_hadith_reference($post_id, $reference_data) {
        global $wpdb;
        
        // Get table name
        $table_name = $this->get_table_name('reference');
        
        // Check if reference already exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE post_id = %d",
            $post_id
        ));
        
        // Prepare data
        $data = array(
            'post_id' => $post_id,
            'book_name' => isset($reference_data['book_name']) ? sanitize_text_field($reference_data['book_name']) : '',
            'volume_number' => isset($reference_data['volume_number']) ? sanitize_text_field($reference_data['volume_number']) : '',
            'page_number' => isset($reference_data['page_number']) ? sanitize_text_field($reference_data['page_number']) : '',
            'hadith_number' => isset($reference_data['hadith_number']) ? sanitize_text_field($reference_data['hadith_number']) : '',
            'authenticity_grade' => isset($reference_data['authenticity_grade']) ? sanitize_text_field($reference_data['authenticity_grade']) : '',
            'additional_reference' => isset($reference_data['additional_reference']) ? sanitize_text_field($reference_data['additional_reference']) : ''
            // Note: chapter_name is now handled in taxonomies, so removed from here
        );
        
        // Format
        $format = array(
            '%d', // post_id
            '%s', // book_name
            '%s', // volume_number
            '%s', // page_number
            '%s', // hadith_number
            '%s', // authenticity_grade
            '%s', // additional_reference
        );
        
        // Update or insert
        if ($existing) {
            // Update
            $result = $wpdb->update(
                $table_name,
                $data,
                array('post_id' => $post_id),
                $format,
                array('%d')
            );
        } else {
            // Insert
            $result = $wpdb->insert(
                $table_name,
                $data,
                $format
            );
        }
        
        return $result !== false;
    }
} 