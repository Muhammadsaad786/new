<?php
/**
 * Logger functionality for the Hadith Fetcher plugin
 */
class Hadith_Fetcher_Logger {
    /**
     * Log table name
     */
    private $table_name;
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'hadith_fetcher_logs';
    }
    
    /**
     * Initialize the logger
     */
    public function init() {
        // Create the logs table if it doesn't exist
        $this->create_logs_table();
        
        // Register cleanup cron job
        if (!wp_next_scheduled('hadith_fetcher_cleanup_logs')) {
            wp_schedule_event(time(), 'daily', 'hadith_fetcher_cleanup_logs');
        }
        add_action('hadith_fetcher_cleanup_logs', array($this, 'cleanup_old_logs'));
    }
    
    /**
     * Create logs table if it doesn't exist
     */
    public function create_logs_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $this->table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            level varchar(20) NOT NULL,
            component varchar(100) NOT NULL,
            message text NOT NULL,
            context text,
            user_id bigint(20),
            ip_address varchar(45),
            PRIMARY KEY  (id),
            KEY level (level),
            KEY component (component),
            KEY timestamp (timestamp)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Add a log entry
     * 
     * @param string $level Log level (info, warning, error, debug)
     * @param string $component Component generating the log
     * @param string $message Log message
     * @param array $context Additional context data
     * @return int|false The log ID or false on failure
     */
    public function add_log($level, $component, $message, $context = array()) {
        global $wpdb;
        
        // Validate log level
        $valid_levels = array('info', 'warning', 'error', 'debug', 'critical');
        if (!in_array($level, $valid_levels)) {
            $level = 'info';
        }
        
        // Prepare log data
        $log_data = array(
            'timestamp' => current_time('mysql'),
            'level' => $level,
            'component' => $component,
            'message' => $message,
            'context' => !empty($context) ? json_encode($context) : null,
            'user_id' => get_current_user_id(),
            'ip_address' => $this->get_client_ip()
        );
        
        // Insert log
        $result = $wpdb->insert(
            $this->table_name,
            $log_data,
            array('%s', '%s', '%s', '%s', '%s', '%d', '%s')
        );
        
        return $result ? $wpdb->insert_id : false;
    }
    
    /**
     * Log an info message
     */
    public function info($component, $message, $context = array()) {
        return $this->add_log('info', $component, $message, $context);
    }
    
    /**
     * Log a warning message
     */
    public function warning($component, $message, $context = array()) {
        return $this->add_log('warning', $component, $message, $context);
    }
    
    /**
     * Log an error message
     */
    public function error($component, $message, $context = array()) {
        return $this->add_log('error', $component, $message, $context);
    }
    
    /**
     * Log a debug message
     */
    public function debug($component, $message, $context = array()) {
        return $this->add_log('debug', $component, $message, $context);
    }
    
    /**
     * Log a critical message
     */
    public function critical($component, $message, $context = array()) {
        return $this->add_log('critical', $component, $message, $context);
    }
    
    /**
     * Get logs with optional filtering
     * 
     * @param array $args Filter arguments
     * @return array Logs
     */
    public function get_logs($args = array()) {
        global $wpdb;
        
        // Default arguments
        $defaults = array(
            'per_page' => 50,
            'page' => 1,
            'level' => '',
            'component' => '',
            'search' => '',
            'date_from' => '',
            'date_to' => '',
            'orderby' => 'timestamp',
            'order' => 'DESC'
        );
        
        // Merge with defaults
        $args = wp_parse_args($args, $defaults);
        
        // Build query
        $query = "SELECT * FROM $this->table_name WHERE 1=1";
        $query_args = array();
        
        // Filter by level
        if (!empty($args['level'])) {
            $query .= " AND level = %s";
            $query_args[] = $args['level'];
        }
        
        // Filter by component
        if (!empty($args['component'])) {
            $query .= " AND component = %s";
            $query_args[] = $args['component'];
        }
        
        // Search in message
        if (!empty($args['search'])) {
            $query .= " AND message LIKE %s";
            $query_args[] = '%' . $wpdb->esc_like($args['search']) . '%';
        }
        
        // Filter by date range
        if (!empty($args['date_from'])) {
            $query .= " AND timestamp >= %s";
            $query_args[] = $args['date_from'] . ' 00:00:00';
        }
        
        if (!empty($args['date_to'])) {
            $query .= " AND timestamp <= %s";
            $query_args[] = $args['date_to'] . ' 23:59:59';
        }
        
        // Order results
        $valid_order_columns = array('timestamp', 'level', 'component');
        $orderby = in_array($args['orderby'], $valid_order_columns) ? $args['orderby'] : 'timestamp';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        $query .= " ORDER BY $orderby $order";
        
        // Calculate pagination
        $offset = ($args['page'] - 1) * $args['per_page'];
        $query .= " LIMIT %d OFFSET %d";
        $query_args[] = $args['per_page'];
        $query_args[] = $offset;
        
        // Execute query
        $results = $wpdb->get_results(
            $wpdb->prepare($query, $query_args)
        );
        
        // Format context data
        foreach ($results as &$result) {
            if (!empty($result->context)) {
                $result->context = json_decode($result->context, true);
            } else {
                $result->context = array();
            }
        }
        
        return $results;
    }
    
    /**
     * Count total logs with filtering
     * 
     * @param array $args Filter arguments
     * @return int Total logs
     */
    public function count_logs($args = array()) {
        global $wpdb;
        
        // Default arguments
        $defaults = array(
            'level' => '',
            'component' => '',
            'search' => '',
            'date_from' => '',
            'date_to' => ''
        );
        
        // Merge with defaults
        $args = wp_parse_args($args, $defaults);
        
        // Build query
        $query = "SELECT COUNT(*) FROM $this->table_name WHERE 1=1";
        $query_args = array();
        
        // Filter by level
        if (!empty($args['level'])) {
            $query .= " AND level = %s";
            $query_args[] = $args['level'];
        }
        
        // Filter by component
        if (!empty($args['component'])) {
            $query .= " AND component = %s";
            $query_args[] = $args['component'];
        }
        
        // Search in message
        if (!empty($args['search'])) {
            $query .= " AND message LIKE %s";
            $query_args[] = '%' . $wpdb->esc_like($args['search']) . '%';
        }
        
        // Filter by date range
        if (!empty($args['date_from'])) {
            $query .= " AND timestamp >= %s";
            $query_args[] = $args['date_from'] . ' 00:00:00';
        }
        
        if (!empty($args['date_to'])) {
            $query .= " AND timestamp <= %s";
            $query_args[] = $args['date_to'] . ' 23:59:59';
        }
        
        // Execute query
        return (int) $wpdb->get_var(
            $wpdb->prepare($query, $query_args)
        );
    }
    
    /**
     * Get all unique components
     * 
     * @return array Component names
     */
    public function get_components() {
        global $wpdb;
        
        $query = "SELECT DISTINCT component FROM $this->table_name ORDER BY component ASC";
        return $wpdb->get_col($query);
    }
    
    /**
     * Clear all logs
     * 
     * @return bool Success
     */
    public function clear_logs() {
        global $wpdb;
        
        return $wpdb->query("TRUNCATE TABLE $this->table_name");
    }
    
    /**
     * Clean up old logs (older than 30 days by default)
     * 
     * @param int $days Number of days to keep logs
     * @return bool Success
     */
    public function cleanup_old_logs($days = 30) {
        global $wpdb;
        
        $date = date('Y-m-d H:i:s', strtotime("-$days days"));
        
        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $this->table_name WHERE timestamp < %s",
                $date
            )
        );
    }
    
    /**
     * Export logs as CSV
     * 
     * @param array $args Filter arguments
     * @return string CSV content
     */
    public function export_csv($args = array()) {
        // Get logs
        $logs = $this->get_logs($args);
        
        // Start output buffering
        ob_start();
        
        // Create a file pointer
        $output = fopen('php://output', 'w');
        
        // Set column headers
        fputcsv($output, array(
            'ID',
            'Timestamp',
            'Level',
            'Component',
            'Message',
            'Context',
            'User ID',
            'IP Address'
        ));
        
        // Output each row of the data
        foreach ($logs as $log) {
            fputcsv($output, array(
                $log->id,
                $log->timestamp,
                $log->level,
                $log->component,
                $log->message,
                !empty($log->context) ? json_encode($log->context) : '',
                $log->user_id,
                $log->ip_address
            ));
        }
        
        // Get the content from the output buffer
        $csv = ob_get_clean();
        
        return $csv;
    }
    
    /**
     * Get client IP address
     * 
     * @return string IP address
     */
    private function get_client_ip() {
        $ip = '';
        
        // Check for proxy server
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = !empty($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
        }
        
        return $ip;
    }
} 