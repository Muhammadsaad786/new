<?php
/**
 * Logging integration for Hadith Fetcher plugin
 */
class Hadith_Fetcher_Logging {
    /**
     * Logger instance
     */
    private $logger;
    
    /**
     * Constructor
     */
    public function __construct($logger) {
        $this->logger = $logger;
        
        // Initialize hooks
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // API hooks
        add_action('hadith_fetcher_before_api_request', array($this, 'log_api_request'), 10, 3);
        add_action('hadith_fetcher_after_api_request', array($this, 'log_api_response'), 10, 4);
        add_action('hadith_fetcher_api_error', array($this, 'log_api_error'), 10, 4);
        
        // Parsing hooks
        add_action('hadith_fetcher_before_parse_html', array($this, 'log_parse_start'), 10, 4);
        add_action('hadith_fetcher_after_parse_html', array($this, 'log_parse_complete'), 10, 5);
        add_action('hadith_fetcher_parse_element', array($this, 'log_parse_element'), 10, 4);
        
        // Database hooks
        add_action('hadith_fetcher_before_post_create', array($this, 'log_post_create_start'), 10, 1);
        add_action('hadith_fetcher_after_post_create', array($this, 'log_post_create_complete'), 10, 2);
        add_action('hadith_fetcher_before_post_update', array($this, 'log_post_update_start'), 10, 2);
        add_action('hadith_fetcher_after_post_update', array($this, 'log_post_update_complete'), 10, 2);
        
        // Meta/taxonomy hooks
        add_action('hadith_fetcher_before_meta_update', array($this, 'log_meta_update'), 10, 3);
        add_action('hadith_fetcher_before_taxonomy_update', array($this, 'log_taxonomy_update'), 10, 3);
        
        // Translation hooks
        add_action('hadith_fetcher_before_translation_save', array($this, 'log_translation_save'), 10, 4);
        add_action('hadith_fetcher_after_translation_save', array($this, 'log_translation_saved'), 10, 5);
        
        // Narrator hooks
        add_action('hadith_fetcher_before_narrator_save', array($this, 'log_narrator_save'), 10, 3);
        add_action('hadith_fetcher_after_narrator_save', array($this, 'log_narrator_saved'), 10, 4);
        
        // Reference hooks
        add_action('hadith_fetcher_before_reference_save', array($this, 'log_reference_save'), 10, 2);
        add_action('hadith_fetcher_after_reference_save', array($this, 'log_reference_saved'), 10, 3);
        
        // Bulk import hooks
        add_action('hadith_fetcher_bulk_import_start', array($this, 'log_bulk_import_start'), 10, 3);
        add_action('hadith_fetcher_bulk_import_progress', array($this, 'log_bulk_import_progress'), 10, 5);
        add_action('hadith_fetcher_bulk_import_complete', array($this, 'log_bulk_import_complete'), 10, 4);
        
        // Settings hooks
        add_action('hadith_fetcher_settings_updated', array($this, 'log_settings_updated'), 10, 2);
    }
    
    /**
     * Log API request
     */
    public function log_api_request($url, $collection, $hadith_number) {
        $this->logger->info(
            'API Request',
            sprintf(__('Requesting hadith %s from %s', 'hadith-fetcher'), $hadith_number, $collection),
            array(
                'url' => $url,
                'collection' => $collection,
                'hadith_number' => $hadith_number
            )
        );
    }
    
    /**
     * Log API response
     */
    public function log_api_response($url, $collection, $hadith_number, $response) {
        $status_code = is_wp_error($response) ? 'error' : wp_remote_retrieve_response_code($response);
        
        $this->logger->info(
            'API Response',
            sprintf(__('Received response for hadith %s from %s (Status: %s)', 'hadith-fetcher'), 
                $hadith_number, 
                $collection, 
                $status_code
            ),
            array(
                'url' => $url,
                'collection' => $collection,
                'hadith_number' => $hadith_number,
                'status_code' => $status_code
            )
        );
    }
    
    /**
     * Log API error
     */
    public function log_api_error($url, $collection, $hadith_number, $error) {
        $error_message = is_wp_error($error) ? $error->get_error_message() : (string) $error;
        
        $this->logger->error(
            'API Error',
            sprintf(__('Error requesting hadith %s from %s: %s', 'hadith-fetcher'), 
                $hadith_number, 
                $collection, 
                $error_message
            ),
            array(
                'url' => $url,
                'collection' => $collection,
                'hadith_number' => $hadith_number,
                'error' => $error_message
            )
        );
    }
    
    /**
     * Log HTML parsing start
     */
    public function log_parse_start($html, $collection, $book, $hadith_number) {
        $html_length = strlen($html);
        
        $this->logger->debug(
            'HTML Parser',
            sprintf(__('Starting to parse HTML for hadith %s from %s (HTML size: %d bytes)', 'hadith-fetcher'), 
                $hadith_number, 
                $collection, 
                $html_length
            ),
            array(
                'collection' => $collection,
                'book' => $book,
                'hadith_number' => $hadith_number,
                'html_length' => $html_length
            )
        );
    }
    
    /**
     * Log HTML parsing complete
     */
    public function log_parse_complete($html, $collection, $book, $hadith_number, $hadith_data) {
        $this->logger->debug(
            'HTML Parser',
            sprintf(__('Completed parsing HTML for hadith %s from %s', 'hadith-fetcher'), 
                $hadith_number, 
                $collection
            ),
            array(
                'collection' => $collection,
                'book' => $book,
                'hadith_number' => $hadith_number,
                'hadith_data' => $this->sanitize_log_data($hadith_data)
            )
        );
    }
    
    /**
     * Log element parsing
     */
    public function log_parse_element($element_name, $selector, $value, $hadith_data) {
        $this->logger->debug(
            'HTML Parser',
            sprintf(__('Parsed element "%s" with selector "%s"', 'hadith-fetcher'), 
                $element_name, 
                $selector
            ),
            array(
                'element' => $element_name,
                'selector' => $selector,
                'value_length' => is_string($value) ? strlen($value) : count($value),
                'hadith_data' => $this->sanitize_log_data($hadith_data)
            )
        );
    }
    
    /**
     * Log post creation start
     */
    public function log_post_create_start($hadith_data) {
        $this->logger->info(
            'Database',
            sprintf(__('Creating new hadith post for %s:%s', 'hadith-fetcher'), 
                $hadith_data['collection'], 
                $hadith_data['hadith_number']
            ),
            array(
                'collection' => $hadith_data['collection'],
                'hadith_number' => $hadith_data['hadith_number'],
                'book_name' => $hadith_data['book_name']
            )
        );
    }
    
    /**
     * Log post creation complete
     */
    public function log_post_create_complete($hadith_data, $post_id) {
        $this->logger->info(
            'Database',
            sprintf(__('Created new hadith post (ID: %d) for %s:%s', 'hadith-fetcher'), 
                $post_id,
                $hadith_data['collection'], 
                $hadith_data['hadith_number']
            ),
            array(
                'post_id' => $post_id,
                'collection' => $hadith_data['collection'],
                'hadith_number' => $hadith_data['hadith_number'],
                'book_name' => $hadith_data['book_name']
            )
        );
    }
    
    /**
     * Log post update start
     */
    public function log_post_update_start($hadith_data, $post_id) {
        $this->logger->info(
            'Database',
            sprintf(__('Updating existing hadith post (ID: %d) for %s:%s', 'hadith-fetcher'), 
                $post_id,
                $hadith_data['collection'], 
                $hadith_data['hadith_number']
            ),
            array(
                'post_id' => $post_id,
                'collection' => $hadith_data['collection'],
                'hadith_number' => $hadith_data['hadith_number']
            )
        );
    }
    
    /**
     * Log post update complete
     */
    public function log_post_update_complete($hadith_data, $post_id) {
        $this->logger->info(
            'Database',
            sprintf(__('Updated hadith post (ID: %d) for %s:%s', 'hadith-fetcher'), 
                $post_id,
                $hadith_data['collection'], 
                $hadith_data['hadith_number']
            ),
            array(
                'post_id' => $post_id,
                'collection' => $hadith_data['collection'],
                'hadith_number' => $hadith_data['hadith_number']
            )
        );
    }
    
    /**
     * Log meta update
     */
    public function log_meta_update($post_id, $meta_key, $meta_value) {
        $value_display = is_array($meta_value) ? json_encode($meta_value) : $meta_value;
        
        $this->logger->debug(
            'Database',
            sprintf(__('Setting meta data "%s" for post ID %d', 'hadith-fetcher'), 
                $meta_key, 
                $post_id
            ),
            array(
                'post_id' => $post_id,
                'meta_key' => $meta_key,
                'value_length' => is_string($meta_value) ? strlen($meta_value) : count($meta_value)
            )
        );
    }
    
    /**
     * Log taxonomy update
     */
    public function log_taxonomy_update($post_id, $taxonomy, $terms) {
        $this->logger->debug(
            'Database',
            sprintf(__('Setting taxonomy "%s" terms for post ID %d', 'hadith-fetcher'), 
                $taxonomy, 
                $post_id
            ),
            array(
                'post_id' => $post_id,
                'taxonomy' => $taxonomy,
                'terms' => is_array($terms) ? $terms : array($terms)
            )
        );
    }
    
    /**
     * Log translation save
     */
    public function log_translation_save($post_id, $language_code, $scholar_id, $text) {
        $this->logger->debug(
            'Database',
            sprintf(__('Saving %s translation for post ID %d', 'hadith-fetcher'), 
                $language_code, 
                $post_id
            ),
            array(
                'post_id' => $post_id,
                'language_code' => $language_code,
                'scholar_id' => $scholar_id,
                'text_length' => strlen($text)
            )
        );
    }
    
    /**
     * Log translation saved
     */
    public function log_translation_saved($post_id, $language_code, $scholar_id, $text, $result) {
        $status = $result ? 'success' : 'failed';
        
        $this->logger->debug(
            'Database',
            sprintf(__('%s translation for post ID %d %s', 'hadith-fetcher'), 
                $language_code, 
                $post_id,
                $status
            ),
            array(
                'post_id' => $post_id,
                'language_code' => $language_code,
                'scholar_id' => $scholar_id,
                'result' => $result
            )
        );
    }
    
    /**
     * Log narrator save
     */
    public function log_narrator_save($post_id, $narrator, $position) {
        $this->logger->debug(
            'Database',
            sprintf(__('Saving narrator "%s" for post ID %d', 'hadith-fetcher'), 
                $narrator, 
                $post_id
            ),
            array(
                'post_id' => $post_id,
                'narrator' => $narrator,
                'position' => $position
            )
        );
    }
    
    /**
     * Log narrator saved
     */
    public function log_narrator_saved($post_id, $narrator, $position, $result) {
        $status = $result ? 'success' : 'failed';
        
        $this->logger->debug(
            'Database',
            sprintf(__('Narrator "%s" for post ID %d %s', 'hadith-fetcher'), 
                $narrator, 
                $post_id,
                $status
            ),
            array(
                'post_id' => $post_id,
                'narrator' => $narrator,
                'position' => $position,
                'result' => $result
            )
        );
    }
    
    /**
     * Log reference save
     */
    public function log_reference_save($post_id, $reference_data) {
        $this->logger->debug(
            'Database',
            sprintf(__('Saving reference data for post ID %d', 'hadith-fetcher'), 
                $post_id
            ),
            array(
                'post_id' => $post_id,
                'reference_data' => $reference_data
            )
        );
    }
    
    /**
     * Log reference saved
     */
    public function log_reference_saved($post_id, $reference_data, $result) {
        $status = $result ? 'success' : 'failed';
        
        $this->logger->debug(
            'Database',
            sprintf(__('Reference data for post ID %d %s', 'hadith-fetcher'), 
                $post_id,
                $status
            ),
            array(
                'post_id' => $post_id,
                'result' => $result
            )
        );
    }
    
    /**
     * Log bulk import start
     */
    public function log_bulk_import_start($collection, $start, $end) {
        $this->logger->info(
            'Bulk Import',
            sprintf(__('Starting bulk import for %s hadiths %d to %d', 'hadith-fetcher'), 
                $collection, 
                $start, 
                $end
            ),
            array(
                'collection' => $collection,
                'start' => $start,
                'end' => $end,
                'total' => ($end - $start) + 1
            )
        );
    }
    
    /**
     * Log bulk import progress
     */
    public function log_bulk_import_progress($collection, $current, $start, $end, $result) {
        $status = $result ? 'success' : 'failed';
        $progress = $current - $start + 1;
        $total = ($end - $start) + 1;
        $percent = round(($progress / $total) * 100);
        
        $this->logger->info(
            'Bulk Import',
            sprintf(__('Imported hadith %d of %s (%s) - %d%% complete', 'hadith-fetcher'), 
                $current, 
                $collection,
                $status,
                $percent
            ),
            array(
                'collection' => $collection,
                'current' => $current,
                'progress' => $progress,
                'total' => $total,
                'percent' => $percent,
                'status' => $status,
                'result' => $result
            )
        );
    }
    
    /**
     * Log bulk import complete
     */
    public function log_bulk_import_complete($collection, $start, $end, $results) {
        $total = ($end - $start) + 1;
        $success = count(array_filter($results));
        $failed = $total - $success;
        
        $this->logger->info(
            'Bulk Import',
            sprintf(__('Bulk import complete for %s hadiths %d to %d: %d successful, %d failed', 'hadith-fetcher'), 
                $collection, 
                $start, 
                $end,
                $success,
                $failed
            ),
            array(
                'collection' => $collection,
                'start' => $start,
                'end' => $end,
                'total' => $total,
                'success' => $success,
                'failed' => $failed,
                'results' => $results
            )
        );
    }
    
    /**
     * Log settings updated
     */
    public function log_settings_updated($old_settings, $new_settings) {
        // Find changed settings
        $changes = array();
        
        foreach ($new_settings as $key => $value) {
            if (!isset($old_settings[$key]) || $old_settings[$key] !== $value) {
                $changes[$key] = array(
                    'old' => isset($old_settings[$key]) ? $old_settings[$key] : null,
                    'new' => $value
                );
            }
        }
        
        $this->logger->info(
            'Settings',
            sprintf(__('Settings updated with %d changes', 'hadith-fetcher'), count($changes)),
            array(
                'changes' => $changes
            )
        );
    }
    
    /**
     * Sanitize log data to prevent massive logs
     */
    private function sanitize_log_data($data) {
        if (!is_array($data)) {
            return $data;
        }
        
        $sanitized = array();
        
        foreach ($data as $key => $value) {
            if (is_string($value) && strlen($value) > 100) {
                $sanitized[$key] = substr($value, 0, 100) . '... [' . strlen($value) . ' characters]';
            } elseif (is_array($value)) {
                if (count($value) > 10) {
                    $sanitized[$key] = '[Array with ' . count($value) . ' items]';
                } else {
                    $sanitized[$key] = $this->sanitize_log_data($value);
                }
            } else {
                $sanitized[$key] = $value;
            }
        }
        
        return $sanitized;
    }
} 