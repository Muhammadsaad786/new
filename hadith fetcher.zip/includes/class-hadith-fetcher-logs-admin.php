<?php
/**
 * Admin functionality for the Hadith Fetcher logs
 */
class Hadith_Fetcher_Logs_Admin {
    /**
     * Logger instance
     */
    private $logger;
    
    /**
     * Constructor
     */
    public function __construct($logger) {
        $this->logger = $logger;
        
        // Add submenu page
        add_action('admin_menu', array($this, 'add_submenu_page'));
        
        // Register AJAX handlers
        add_action('wp_ajax_hadith_fetcher_clear_logs', array($this, 'ajax_clear_logs'));
        add_action('wp_ajax_hadith_fetcher_export_logs', array($this, 'ajax_export_logs'));
    }
    
    /**
     * Add submenu page
     */
    public function add_submenu_page() {
        add_submenu_page(
            'hadith-fetcher',
            __('Debug Logs', 'hadith-fetcher'),
            __('Debug Logs', 'hadith-fetcher'),
            'manage_options',
            'hadith-fetcher-logs',
            array($this, 'render_logs_page')
        );
    }
    
    /**
     * Render logs page
     */
    public function render_logs_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Get current filters
        $filters = $this->get_current_filters();
        
        // Get available components for filter dropdown
        $components = $this->logger->get_components();
        
        // Get logs count for pagination
        $total_logs = $this->logger->count_logs($filters);
        $per_page = $filters['per_page'];
        $total_pages = ceil($total_logs / $per_page);
        
        // Get logs
        $logs = $this->logger->get_logs($filters);
        
        // Enqueue assets
        $this->enqueue_assets();
        
        // Start output
        ?>
        <div class="wrap hadith-fetcher-logs">
            <h1><?php _e('Hadith Fetcher - Debug Logs', 'hadith-fetcher'); ?></h1>
            
            <div class="logs-header">
                <div class="logs-filters">
                    <form method="get">
                        <input type="hidden" name="page" value="hadith-fetcher-logs">
                        
                        <div class="filters-row">
                            <div class="filter-item">
                                <label for="level"><?php _e('Level:', 'hadith-fetcher'); ?></label>
                                <select name="level" id="level">
                                    <option value="" <?php selected('', $filters['level']); ?>><?php _e('All Levels', 'hadith-fetcher'); ?></option>
                                    <option value="debug" <?php selected('debug', $filters['level']); ?>><?php _e('Debug', 'hadith-fetcher'); ?></option>
                                    <option value="info" <?php selected('info', $filters['level']); ?>><?php _e('Info', 'hadith-fetcher'); ?></option>
                                    <option value="warning" <?php selected('warning', $filters['level']); ?>><?php _e('Warning', 'hadith-fetcher'); ?></option>
                                    <option value="error" <?php selected('error', $filters['level']); ?>><?php _e('Error', 'hadith-fetcher'); ?></option>
                                    <option value="critical" <?php selected('critical', $filters['level']); ?>><?php _e('Critical', 'hadith-fetcher'); ?></option>
                                </select>
                            </div>
                            
                            <div class="filter-item">
                                <label for="component"><?php _e('Component:', 'hadith-fetcher'); ?></label>
                                <select name="component" id="component">
                                    <option value="" <?php selected('', $filters['component']); ?>><?php _e('All Components', 'hadith-fetcher'); ?></option>
                                    <?php foreach ($components as $component): ?>
                                    <option value="<?php echo esc_attr($component); ?>" <?php selected($component, $filters['component']); ?>>
                                        <?php echo esc_html($component); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-item">
                                <label for="search"><?php _e('Search:', 'hadith-fetcher'); ?></label>
                                <input type="text" name="search" id="search" value="<?php echo esc_attr($filters['search']); ?>" placeholder="<?php _e('Search logs...', 'hadith-fetcher'); ?>">
                            </div>
                        </div>
                        
                        <div class="filters-row">
                            <div class="filter-item">
                                <label for="date_from"><?php _e('From Date:', 'hadith-fetcher'); ?></label>
                                <input type="date" name="date_from" id="date_from" value="<?php echo esc_attr($filters['date_from']); ?>">
                            </div>
                            
                            <div class="filter-item">
                                <label for="date_to"><?php _e('To Date:', 'hadith-fetcher'); ?></label>
                                <input type="date" name="date_to" id="date_to" value="<?php echo esc_attr($filters['date_to']); ?>">
                            </div>
                            
                            <div class="filter-item">
                                <label for="per_page"><?php _e('Per Page:', 'hadith-fetcher'); ?></label>
                                <select name="per_page" id="per_page">
                                    <option value="25" <?php selected(25, $filters['per_page']); ?>>25</option>
                                    <option value="50" <?php selected(50, $filters['per_page']); ?>>50</option>
                                    <option value="100" <?php selected(100, $filters['per_page']); ?>>100</option>
                                    <option value="200" <?php selected(200, $filters['per_page']); ?>>200</option>
                                </select>
                            </div>
                            
                            <div class="filter-item">
                                <button type="submit" class="button button-primary"><?php _e('Filter', 'hadith-fetcher'); ?></button>
                                <a href="<?php echo admin_url('admin.php?page=hadith-fetcher-logs'); ?>" class="button"><?php _e('Reset', 'hadith-fetcher'); ?></a>
                            </div>
                        </div>
                    </form>
                </div>
                
                <div class="logs-actions">
                    <button type="button" id="export-logs" class="button button-secondary"><?php _e('Export CSV', 'hadith-fetcher'); ?></button>
                    <button type="button" id="clear-logs" class="button button-secondary"><?php _e('Clear All Logs', 'hadith-fetcher'); ?></button>
                </div>
            </div>
            
            <div class="logs-table-container">
                <?php if (empty($logs)): ?>
                <div class="logs-empty">
                    <p><?php _e('No logs found.', 'hadith-fetcher'); ?></p>
                </div>
                <?php else: ?>
                <table class="wp-list-table widefat fixed striped logs-table">
                    <thead>
                        <tr>
                            <th><?php _e('Time', 'hadith-fetcher'); ?></th>
                            <th><?php _e('Level', 'hadith-fetcher'); ?></th>
                            <th><?php _e('Component', 'hadith-fetcher'); ?></th>
                            <th><?php _e('Message', 'hadith-fetcher'); ?></th>
                            <th><?php _e('User', 'hadith-fetcher'); ?></th>
                            <th><?php _e('Details', 'hadith-fetcher'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html(get_date_from_gmt($log->timestamp, 'Y-m-d H:i:s')); ?></td>
                            <td>
                                <span class="log-level log-level-<?php echo esc_attr($log->level); ?>">
                                    <?php echo esc_html(ucfirst($log->level)); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($log->component); ?></td>
                            <td><?php echo esc_html($log->message); ?></td>
                            <td>
                                <?php if ($log->user_id): ?>
                                    <?php $user = get_user_by('id', $log->user_id); ?>
                                    <?php echo $user ? esc_html($user->user_login) : __('Unknown', 'hadith-fetcher'); ?>
                                <?php else: ?>
                                    <?php _e('System', 'hadith-fetcher'); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($log->context)): ?>
                                <button type="button" class="button button-small view-context" data-context="<?php echo esc_attr(json_encode($log->context)); ?>">
                                    <?php _e('View', 'hadith-fetcher'); ?>
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($total_pages > 1): ?>
                <div class="tablenav">
                    <div class="tablenav-pages">
                        <span class="displaying-num">
                            <?php printf(
                                _n('%s item', '%s items', $total_logs, 'hadith-fetcher'),
                                number_format_i18n($total_logs)
                            ); ?>
                        </span>
                        
                        <span class="pagination-links">
                            <?php
                            // First page link
                            if ($filters['page'] > 1) {
                                printf(
                                    '<a class="first-page button" href="%s"><span aria-hidden="true">%s</span></a>',
                                    esc_url(add_query_arg('paged', 1)),
                                    '«'
                                );
                                
                                printf(
                                    '<a class="prev-page button" href="%s"><span aria-hidden="true">%s</span></a>',
                                    esc_url(add_query_arg('paged', max(1, $filters['page'] - 1))),
                                    '‹'
                                );
                            } else {
                                echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">«</span>';
                                echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span>';
                            }
                            
                            // Current page
                            printf(
                                '<span class="paging-input"><input class="current-page" type="text" name="paged" value="%s" size="1"> %s <span class="total-pages">%s</span></span>',
                                esc_attr($filters['page']),
                                _x('of', 'pagination', 'hadith-fetcher'),
                                number_format_i18n($total_pages)
                            );
                            
                            // Next/last page links
                            if ($filters['page'] < $total_pages) {
                                printf(
                                    '<a class="next-page button" href="%s"><span aria-hidden="true">%s</span></a>',
                                    esc_url(add_query_arg('paged', min($total_pages, $filters['page'] + 1))),
                                    '›'
                                );
                                
                                printf(
                                    '<a class="last-page button" href="%s"><span aria-hidden="true">%s</span></a>',
                                    esc_url(add_query_arg('paged', $total_pages)),
                                    '»'
                                );
                            } else {
                                echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>';
                                echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">»</span>';
                            }
                            ?>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            
            <!-- Modal for log details -->
            <div id="log-details-modal" class="log-details-modal" style="display: none;">
                <div class="log-details-content">
                    <span class="close">&times;</span>
                    <h2><?php _e('Log Details', 'hadith-fetcher'); ?></h2>
                    <div class="log-context">
                        <pre><code></code></pre>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Get current filters from query string
     */
    private function get_current_filters() {
        return array(
            'level' => isset($_GET['level']) ? sanitize_text_field($_GET['level']) : '',
            'component' => isset($_GET['component']) ? sanitize_text_field($_GET['component']) : '',
            'search' => isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '',
            'date_from' => isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '',
            'date_to' => isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '',
            'per_page' => isset($_GET['per_page']) ? max(25, intval($_GET['per_page'])) : 50,
            'page' => isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1
        );
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_assets() {
        wp_enqueue_style(
            'hadith-fetcher-logs-css',
            plugins_url('/assets/css/logs-admin.css', dirname(__FILE__)),
            array(),
            HADITH_FETCHER_VERSION
        );
        
        wp_enqueue_script(
            'hadith-fetcher-logs-js',
            plugins_url('/assets/js/logs-admin.js', dirname(__FILE__)),
            array('jquery'),
            HADITH_FETCHER_VERSION,
            true
        );
        
        wp_localize_script('hadith-fetcher-logs-js', 'hadithFetcherLogs', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('hadith_fetcher_logs'),
            'confirmClear' => __('Are you sure you want to clear all logs? This action cannot be undone.', 'hadith-fetcher'),
            'clearSuccess' => __('All logs have been cleared successfully.', 'hadith-fetcher'),
            'clearError' => __('An error occurred while clearing logs.', 'hadith-fetcher')
        ));
    }
    
    /**
     * AJAX handler for clearing logs
     */
    public function ajax_clear_logs() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hadith_fetcher_logs')) {
            wp_send_json_error(__('Invalid security token.', 'hadith-fetcher'));
            exit;
        }
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have permission to clear logs.', 'hadith-fetcher'));
            exit;
        }
        
        // Clear logs
        $result = $this->logger->clear_logs();
        
        if ($result !== false) {
            wp_send_json_success(__('All logs have been cleared successfully.', 'hadith-fetcher'));
        } else {
            wp_send_json_error(__('Failed to clear logs.', 'hadith-fetcher'));
        }
    }
    
    /**
     * AJAX handler for exporting logs
     */
    public function ajax_export_logs() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hadith_fetcher_logs')) {
            wp_send_json_error(__('Invalid security token.', 'hadith-fetcher'));
            exit;
        }
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have permission to export logs.', 'hadith-fetcher'));
            exit;
        }
        
        // Get filters
        $filters = array(
            'level' => isset($_POST['level']) ? sanitize_text_field($_POST['level']) : '',
            'component' => isset($_POST['component']) ? sanitize_text_field($_POST['component']) : '',
            'search' => isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '',
            'date_from' => isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '',
            'date_to' => isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '',
            'per_page' => 10000 // Export all logs matching filters
        );
        
        // Export logs
        $csv = $this->logger->export_csv($filters);
        
        // Send CSV as download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=hadith-fetcher-logs-' . date('Y-m-d') . '.csv');
        
        echo $csv;
        exit;
    }
} 