<?php
/**
 * Main plugin class
 */
class Hadith_Fetcher {
    /**
     * Initialize the plugin
     */
    public function init() {
        // Check if the hadith post type exists and register it if needed
        $this->register_post_type();
        
        // Register taxonomies
        $this->register_taxonomies();
        
        // Ensure database tables exist
        $this->check_database_tables();
        
        // Save post meta
        add_action('save_post', array($this, 'save_post_meta'), 10, 2);
    }
    
    /**
     * Register the hadith post type if it doesn't exist
     */
    private function register_post_type() {
        if (!post_type_exists('hadith')) {
            register_post_type('hadith', array(
                'labels' => array(
                    'name' => __('Hadiths', 'hadith-fetcher'),
                    'singular_name' => __('Hadith', 'hadith-fetcher'),
                    'add_new' => __('Add New', 'hadith-fetcher'),
                    'add_new_item' => __('Add New Hadith', 'hadith-fetcher'),
                    'edit_item' => __('Edit Hadith', 'hadith-fetcher'),
                    'new_item' => __('New Hadith', 'hadith-fetcher'),
                    'view_item' => __('View Hadith', 'hadith-fetcher'),
                    'search_items' => __('Search Hadiths', 'hadith-fetcher'),
                    'not_found' => __('No hadiths found', 'hadith-fetcher'),
                    'not_found_in_trash' => __('No hadiths found in Trash', 'hadith-fetcher'),
                    'menu_name' => __('Hadiths', 'hadith-fetcher'),
                ),
                'public' => true,
                'has_archive' => true,
                'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
                'menu_icon' => 'dashicons-book-alt',
                'rewrite' => array('slug' => 'hadith'),
                'show_in_rest' => true,
            ));
            
            // Flush rewrite rules after registering post type
            flush_rewrite_rules();
        }
    }
    
    /**
     * Register taxonomies for hadiths
     */
    private function register_taxonomies() {
        // Create taxonomies if they don't exist
        $taxonomies = array(
            'books' => __('Books', 'hadith-fetcher'),
            'authenticity' => __('Authenticity', 'hadith-fetcher'),
            'narrators' => __('Narrators', 'hadith-fetcher')
        );
        
        foreach ($taxonomies as $taxonomy => $label) {
            if (!taxonomy_exists($taxonomy)) {
                register_taxonomy(
                    $taxonomy,
                    'hadith',
                    array(
                        'label' => $label,
                        'hierarchical' => ($taxonomy === 'narrators') ? false : true,
                        'public' => true,
                        'show_ui' => true,
                        'show_in_menu' => true,
                        'show_admin_column' => true,
                        'query_var' => true,
                        'rewrite' => array('slug' => $taxonomy),
                    )
                );
            }
        }
    }
    
    /**
     * Check if database tables exist and create them if they don't
     */
    private function check_database_tables() {
        $db = new Hadith_Fetcher_Database();
        if (!$db->tables_exist()) {
            $db->check_tables();
        }
    }
    
    /**
     * Save post meta
     */
    public function save_post_meta($post_id, $post) {
        // Only save for hadith post type
        if ($post->post_type !== 'hadith') {
            return;
        }
        
        // If this is an autosave, we don't want to do anything
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check the user's permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // The meta fields will be handled by the API when fetching
    }
} 